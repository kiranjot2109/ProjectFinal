import { Link } from "react-router-dom";
export default function AboutUs(){
    return(
        <>
  <section
    className="breadcrumb-section set-bg"
    data-setbg="assets/img/breadcrumb-bg.jpg"
    style={{backgroundImage:"url(assets/img/breadcrumb-bg.jpg)"}}
  >
    <div className="container">
      <div className="row">
        <div className="col-lg-12 text-center">
          <div className="breadcrumb-text">
            <h2>About us</h2>
            <div className="bt-option">
              <Link to="/">Home</Link>
              <span>About</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Breadcrumb Section End */}
  {/* ChoseUs Section Begin */}
  <section className="choseus-section spad">
    <div className="container">
      <div className="row">
        <div className="col-lg-12">
          <div className="section-title">
            <span>Why chose us?</span>
            <h2>PUSH YOUR LIMITS FORWARD</h2>
          </div>
        </div>
      </div>
      <div className="row">
        <div className="col-lg-3 col-sm-6">
          <div className="cs-item">
            <span className="flaticon-034-stationary-bike" />
            <h4>Modern equipment</h4>
           
          </div>
        </div>
        <div className="col-lg-3 col-sm-6">
          <div className="cs-item">
            <span className="flaticon-033-juice" />
            <h4>Healthy nutrition plan</h4>
          
          </div>
        </div>
        <div className="col-lg-3 col-sm-6">
          <div className="cs-item">
            <span className="flaticon-002-dumbell" />
            <h4>Proffesponal training plan</h4>
          
          </div>
        </div>
        <div className="col-lg-3 col-sm-6">
          <div className="cs-item">
            <span className="flaticon-014-heart-beat" />
            <h4>Unique to your needs</h4>
        
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* ChoseUs Section End */}
 
  {/* Team Section Begin */}
  <section className="team-section team-page spad">
    <div className="container">
      <div className="row">
        <div className="col-lg-12">
          <div className="team-title">
            <div className="section-title">
              <span>Our Team</span>
              <h2>TRAIN WITH EXPERTS</h2>
            </div>
            {/* <a href="#" className="primary-btn btn-normal appoinment-btn">
              appointment
            </a> */}
          </div>
        </div>
      </div>
      <div className="row">
        <div className="col-lg-4 col-sm-6">
          <div className="ts-item set-bg"
          style={{backgroundImage:"url(/assets/img/team/team-1.jpg)"}}
          >
            <div className="ts_text">
              <h4>Simran</h4>
              <span>Gym Trainer</span>
              <div className="tt_social">
                <a href="#">
                  <i className="fa fa-facebook" />
                </a>
                <a href="#">
                  <i className="fa fa-twitter" />
                </a>
                <a href="#">
                  <i className="fa fa-youtube-play" />
                </a>
                <a href="#">
                  <i className="fa fa-instagram" />
                </a>
                <a href="#">
                  <i className="fa  fa-envelope-o" />
                </a>
              </div>
            </div>
          </div>
        </div>
        <div className="col-lg-4 col-sm-6">
          <div className="ts-item set-bg" style={{backgroundImage:"url(/assets/img/team/team-2.jpg)"}}>
            <div className="ts_text">
              <h4>Paras</h4>
              <span>Gym Trainer</span>
              <div className="tt_social">
                <a href="#">
                  <i className="fa fa-facebook" />
                </a>
                <a href="#">
                  <i className="fa fa-twitter" />
                </a>
                <a href="#">
                  <i className="fa fa-youtube-play" />
                </a>
                <a href="#">
                  <i className="fa fa-instagram" />
                </a>
                <a href="#">
                  <i className="fa  fa-envelope-o" />
                </a>
              </div>
            </div>
          </div>
        </div>
        {/* <div className="col-lg-4 col-sm-6">
          <div className="ts-item set-bg"  style={{backgroundImage:"url(/assets/img/team/team-3.jpg)"}}>
            <div className="ts_text">
              <h4>Athart Rachel</h4>
              <span>Gym Trainer</span>
              <div className="tt_social">
                <a href="#">
                  <i className="fa fa-facebook" />
                </a>
                <a href="#">
                  <i className="fa fa-twitter" />
                </a>
                <a href="#">
                  <i className="fa fa-youtube-play" />
                </a>
                <a href="#">
                  <i className="fa fa-instagram" />
                </a>
                <a href="#">
                  <i className="fa  fa-envelope-o" />
                </a>
              </div>
            </div>
          </div>
        </div>
        <div className="col-lg-4 col-sm-6">
          <div className="ts-item set-bg" style={{backgroundImage:"url(/assets/img/team/team-4.jpg)"}}>
            <div className="ts_text">
              <h4>Athart Rachel</h4>
              <span>Gym Trainer</span>
              <div className="tt_social">
                <a href="#">
                  <i className="fa fa-facebook" />
                </a>
                <a href="#">
                  <i className="fa fa-twitter" />
                </a>
                <a href="#">
                  <i className="fa fa-youtube-play" />
                </a>
                <a href="#">
                  <i className="fa fa-instagram" />
                </a>
                <a href="#">
                  <i className="fa  fa-envelope-o" />
                </a>
              </div>
            </div>
          </div>
        </div> */}
        <div className="col-lg-4 col-sm-6">
          <div className="ts-item set-bg"  style={{backgroundImage:"url(/assets/img/team/team-5.jpg)"}}>
            <div className="ts_text">
              <h4>Kiran</h4>
              <span>Gym Trainer</span>
              {/* <div className="tt_social">
                <a href="#">
                  <i className="fa fa-facebook" />
                </a>
                <a href="#">
                  <i className="fa fa-twitter" />
                </a>
                <a href="#">
                  <i className="fa fa-youtube-play" />
                </a>
                <a href="#">
                  <i className="fa fa-instagram" />
                </a>
                <a href="#">
                  <i className="fa  fa-envelope-o" />
                </a>
              </div> */}
            </div>
          </div>
        </div>
        {/* <div className="col-lg-4 col-sm-6">
          <div className="ts-item set-bg"  style={{backgroundImage:"url(/assets/img/team/team-6.jpg)"}}>
            <div className="ts_text">
              <h4>Athart Rachel</h4>
              <span>Gym Trainer</span>
              <div className="tt_social">
                <a href="#">
                  <i className="fa fa-facebook" />
                </a>
                <a href="#">
                  <i className="fa fa-twitter" />
                </a>
                <a href="#">
                  <i className="fa fa-youtube-play" />
                </a>
                <a href="#">
                  <i className="fa fa-instagram" />
                </a>
                <a href="#">
                  <i className="fa  fa-envelope-o" />
                </a>
              </div>
            </div>
          </div>
        </div> */}
      </div>
    </div>
  </section>
 
  {/* Team Section End */}
  {/* Banner Section Begin */}
  <section className="banner-section set-bg" data-setbg="assets/img/banner-bg.jpg"  style={{backgroundImage:"url(assets/img/banner-bg.jpg)"}}>
    <div className="container">
      <div className="row">
        <div className="col-lg-12 text-center">
          <div className="bs-text">
            <h2>registration now to get more deals</h2>
            <div className="bt-tips">
              Where health, beauty and fitness meet.
            </div>
            <a href="#" className="primary-btn  btn-normal">
              Appointment
            </a>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Banner Section End */}
 
  {/* Get In Touch Section Begin */}
  <div className="gettouch-section">
    <div className="container">
      <div className="row">
        <div className="col-md-4">
          <div className="gt-text">
            <i className="fa fa-map-marker" />
            <p>
              Dasuya ,Distt: Hoshiarpur
            </p>
          </div>
        </div>
        <div className="col-md-4">
          <div className="gt-text">
            <i className="fa fa-mobile" />
            <ul>
              
              <li>9877937986</li>
            </ul>
          </div>
        </div>
        <div className="col-md-4">
          <div className="gt-text email">
            <i className="fa fa-envelope" />
            <p>kiran@gmail</p>
          </div>
        </div>
      </div>
    </div>
  </div>

</>

    )
}