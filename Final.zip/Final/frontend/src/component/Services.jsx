import { Link, useNavigate } from "react-router-dom";
import ApiServices from "./layout/ApiServices";
import { useEffect, useState } from "react";

export default function Services(){
  const [data,setData]=useState([])
  let [color, setColor] = useState("#2c4964;");
  const [isLoading, setIsLoading] = useState(true);
  const [limit, setLimit] = useState(5);
  const token = sessionStorage.getItem('token')
  const navigate = useNavigate()
  const loginPage= ()=>{
      window.alert("Login to View More!")
      navigate('/login')
  }
  useEffect(()=>{
    ApiServices.GetAllPackages().then((res)=>{
      console.log("Result is",res)
      // console.log(res.data.data)
      setData(res.data.data)
      // setSpecialist(res.data.data)
  })
    .catch((err)=>{console.log(err)})
    setTimeout(() => {
      setIsLoading(false);
    }, 1500);
  },[])
    return(
        <>
        {/* Breadcrumb Section Begin */}
        <section
          className="breadcrumb-section set-bg"
          data-setbg="/assets/img/breadcrumb-bg.jpg"
    style={{backgroundImage:"url(assets/img/breadcrumb-bg.jpg)"}}

        >
          <div className="container">
            <div className="row">
              <div className="col-lg-12 text-center">
                <div className="breadcrumb-text">
                  <h2>Services</h2>
                  <div className="bt-option">
                    <Link to="/">Home</Link>
                    <span>Services</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* Breadcrumb Section End */}
        {/* Services Section Begin */}
        {/* <section className="services-section spad">
          <div className="container">
            <div className="row">
              <div className="col-lg-12">
                <div className="section-title">
                  <span>What we do?</span>
                  <h2>PUSH YOUR LIMITS FORWARD</h2>
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col-lg-3 order-lg-1 col-md-6 p-0">
                <div className="ss-pic">
                  <img src="/assets/img/services/services-1.jpg" alt="" />
                </div>
              </div>
              <div className="col-lg-3 order-lg-2 col-md-6 p-0">
                <div className="ss-text">
                  <h4>Personal training</h4>
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                    eiusmod tempor ut dolore facilisis.
                  </p>
                  <a href="#">Explore</a>
                </div>
              </div>
              <div className="col-lg-3 order-lg-3 col-md-6 p-0">
                <div className="ss-pic">
                  <img src="/assets/img/services/services-2.jpg" alt="" />
                </div>
              </div>
              <div className="col-lg-3 order-lg-4 col-md-6 p-0">
                <div className="ss-text">
                  <h4>Group fitness classes</h4>
                  <p>
                    Quis ipsum suspendisse ultrices gravida. Risus commodo viverra
                    maecenas accumsan lacus.
                  </p>
                  <a href="#">Explore</a>
                </div>
              </div>
              <div className="col-lg-3 order-lg-8 col-md-6 p-0">
                <div className="ss-pic">
                  <img src="/assets/img/services/services-4.jpg" alt="" />
                </div>
              </div>
              <div className="col-lg-3 order-lg-7 col-md-6 p-0">
                <div className="ss-text second-row">
                  <h4>Body building</h4>
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                    eiusmod tempor ut dolore facilisis.
                  </p>
                  <a href="#">Explore</a>
                </div>
              </div>
              <div className="col-lg-3 order-lg-6 col-md-6 p-0">
                <div className="ss-pic">
                  <img src="/assets/img/services/services-3.jpg" alt="" />
                </div>
              </div>
              <div className="col-lg-3 order-lg-5 col-md-6 p-0">
                <div className="ss-text second-row">
                  <h4>Strength training</h4>
                  <p>
                    Quis ipsum suspendisse ultrices gravida. Risus commodo viverra
                    maecenas accumsan lacus.
                  </p>
                  <a href="#">Explore</a>
                </div>
              </div>
            </div>
          </div>
        </section> */}
        {/* Services Section End */}
        {/* Banner Section Begin */}
        {/* <section className="banner-section set-bg" data-setbg="/assets/img/banner-bg.jpg" style={{backgroundImage:"url(assets/img/banner-bg.jpg)"}}>
          <div className="container">
            <div className="row">
              <div className="col-lg-12 text-center">
                <div className="bs-text service-banner">
                  <h2>Exercise until the body obeys.</h2>
                  <div className="bt-tips">
                    Where health, beauty and fitness meet.
                  </div>
                  <a
                    href="https://www.youtube.com/watch?v=EzKkl64rRbM"
                    className="play-btn video-popup"
                  >
                    <i className="fa fa-caret-right" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section> */}
        {/* Banner Section End */}
        {/* Pricing Section Begin */}
        <section className="pricing-section service-pricing spad">
          <div className="container">
            <div className="row">
              <div className="col-lg-12">
                <div className="section-title">
                  <span>Our Plan</span>
                  <h2>Choose your pricing plan</h2>
                
                
                </div>
              </div>
            </div>
            <div className="row">
          {data && data.length>0?
          data?.slice(0,limit).map(
                    (el,index)=>(
            <>
          <div>
          <div className="col-lg-12 col-md-8">
                <div className="ps-item">
                  <h4 className="text-warning">{el.duration }</h4>
                  <div className="pi-price">
                    <h2>{el.name}</h2>
                    <span>Rs:{el.price }</span>
                  </div>
                  {/* <ul>
                    <li>Free riding</li>
                    <li>Unlimited equipments</li>
                    <li>Personal trainer</li>
                    <li>Weight losing classes</li>
                    <li>Month to mouth</li>
                    <li>No time restriction</li>
                  </ul> */}
                  {/* <a href="#" className="primary-btn pricing-btn">
                    Enroll now
                  </a> */}
                  {/* <a href="#" className="thumb-icon">
                    <i className="fa fa-picture-o" />
                  </a> */}
                </div>
              </div>         
      </div> 
    
      
</>))
          
      
       
:
<h4>Currently No Packages Available!!</h4>
}
  
    </div>
    </div>
    {!token?
    <center> 
   <button className="btn btn-primary text-light mt-4 w-25" onClick={loginPage}>View More</button>
   </center>
   :
    <center>
      <Link to={'/packages'}>
    <button className="btn btn-primary text-light mt-4 w-25">View More</button>
    </Link>
    </center>
   }


              {/* <div className="col-lg-4 col-md-8">
                <div className="ps-item">
                  <h3>Class drop-in</h3>
                  <div className="pi-price">
                    <h2>$ 39.0</h2>
                    <span>SINGLE CLASS</span>
                  </div>
                  <ul>
                    <li>Free riding</li>
                    <li>Unlimited equipments</li>
                    <li>Personal trainer</li>
                    <li>Weight losing classes</li>
                    <li>Month to mouth</li>
                    <li>No time restriction</li>
                  </ul>
                  <a href="#" className="primary-btn pricing-btn">
                    Enroll now
                  </a>
                  <a href="#" className="thumb-icon">
                    <i className="fa fa-picture-o" />
                  </a>
                </div>
              </div> */}
              {/* <div className="col-lg-4 col-md-8">
                <div className="ps-item">
                  <h3>12 Month unlimited</h3>
                  <div className="pi-price">
                    <h2>$ 99.0</h2>
                    <span>SINGLE CLASS</span>
                  </div>
                  <ul>
                    <li>Free riding</li>
                    <li>Unlimited equipments</li>
                    <li>Personal trainer</li>
                    <li>Weight losing classes</li>
                    <li>Month to mouth</li>
                    <li>No time restriction</li>
                  </ul>
                  <a href="#" className="primary-btn pricing-btn">
                    Enroll now
                  </a>
                  <a href="#" className="thumb-icon">
                    <i className="fa fa-picture-o" />
                  </a>
                </div>
              </div>
              <div className="col-lg-4 col-md-8">
                <div className="ps-item">
                  <h3>6 Month unlimited</h3>
                  <div className="pi-price">
                    <h2>$ 59.0</h2>
                    <span>SINGLE CLASS</span>
                  </div>
                  <ul>
                    <li>Free riding</li>
                    <li>Unlimited equipments</li>
                    <li>Personal trainer</li>
                    <li>Weight losing classes</li>
                    <li>Month to mouth</li>
                    <li>No time restriction</li>
                  </ul>
                  <a href="#" className="primary-btn pricing-btn">
                    Enroll now
                  </a>
                  <a href="#" className="thumb-icon">
                    <i className="fa fa-picture-o" />
                  </a>
                </div>
              </div> */}
         
         
        </section>
        {/* Pricing Section End */}
        {/* Get In Touch Section Begin */}
        <div className="gettouch-section">
          <div className="container">
            <div className="row">
              <div className="col-md-4">
                <div className="gt-text">
                  <i className="fa fa-map-marker" />
                  <p>
              Dasuya ,Distt: Hoshiarpur
            </p>
                </div>
              </div>
              <div className="col-md-4">
                <div className="gt-text">
                  <i className="fa fa-mobile" />
                  <ul>
                 
                  <li>9877937986</li>
                  </ul>
                </div>
              </div>
              <div className="col-md-4">
                <div className="gt-text email">
                  <i className="fa fa-envelope" />
                  <p>kiran@gmail</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Get In Touch Section End */}
    
        {/* Search model Begin */}
        <div className="search-model">
          <div className="h-100 d-flex align-items-center justify-content-center">
            <div className="search-close-switch">+</div>
            <form className="search-model-form">
              <input type="text" id="search-input" placeholder="Search here....." />
            </form>
          </div>
        </div>
        {/* Search model end */}
        {/* Js Plugins */}
      </>
         
    )
}