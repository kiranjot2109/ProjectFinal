import { Link } from "react-router-dom";
import React, { useState } from "react";

export default function  BmiCalculate(){
  const [height, setHeight] = useState("");
  const [weight, setWeight] = useState("");
  const [age, setAge] = useState("");
  const [sex, setGender] = useState("");
  const [bmi, setBmi] = useState(null);
  const [message, setMessage] = useState("");

  const calculateBMI = () => {
    if (!height || !weight) {
      setMessage("Please enter valid height and weight");
      return;
    }
    const heightInMeters = height / 100;
    const bmiValue = (weight / (heightInMeters * heightInMeters)).toFixed(2);
    setBmi(bmiValue);

    if (bmiValue < 18.5) {
      setMessage("Underweight");
    } else if (bmiValue >= 18.5 && bmiValue < 24.9) {
      setMessage("Normal weight");
    } else if (bmiValue >= 25 && bmiValue < 29.9) {
      setMessage("Overweight");
    } else {
      setMessage("Obese");
    }
  };

    return(
        <>
  {/* Breadcrumb Section Begin */}
  <section
    className="breadcrumb-section set-bg"
    data-setbg="assets/img/breadcrumb-bg.jpg"
    style={{backgroundImage:"url(assets/img/breadcrumb-bg.jpg)"}}

  >
    <div className="container">
      <div className="row">
        <div className="col-lg-12 text-center">
          <div className="breadcrumb-text">
            <h2>BMI calculator</h2>
            <div className="bt-option">
              <Link to="/">Home</Link>
              <a href="/">Pages</a>
              <span>BMI calculator</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Breadcrumb Section End */}
  {/* BMI Calculator Section Begin */}
  <section className="bmi-calculator-section spad">
    <div className="container">
      <div className="row">
        <div className="col-lg-6">
          <div className="section-title chart-title">
            <span>check your body</span>
            <h2>BMI CALCULATOR CHART</h2>
          </div>
          <div className="chart-table">
            <table>
              <thead>
                <tr>
                  <th>Bmi</th>
                  <th>WEIGHT STATUS</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="point">Below 18.5</td>
                  <td>Underweight</td>
                </tr>
                <tr>
                  <td className="point">18.5 - 24.9</td>
                  <td>Normal weight</td>
                </tr>
                <tr>
                  <td className="point">25.0 - 29.9</td>
                  <td>Overweight</td>
                </tr>
                <tr>
                  <td className="point">30.0 - and Above</td>
                  <td>Obese</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div className="col-lg-6">
          <div className="section-title chart-calculate-title">
            <span>check your body</span>
            <h2>CALCULATE YOUR BMI</h2>
          </div>
          <div className="chart-calculate-form">
            <p>
             
            </p>
            <form action="#">
              <div className="row">
                <div className="col-sm-6">
                  <label style={{color:"white"}}>Height</label>
                  <input type="number"
          placeholder="Height / cm"
          value={height}
          onChange={(e) => setHeight(e.target.value)}/>
                </div>
                <div className="col-sm-6">
                <label style={{color:"white"}}>Weight</label>
                  <input  type="number"
          placeholder="Weight / kg"
          value={weight}
          onChange={(e) => setWeight(e.target.value)} />
                </div>
                <div className="col-sm-6">
                <label style={{color:"white"}}>Age</label>
                  <input type="number"
          placeholder="Age"
          value={age}
          onChange={(e) => setAge(e.target.value)}/>
                </div>
                <div className="col-sm-6">
                <label style={{color:"white"}}>Gender</label>
                <br></br>
                  <select className="form-select w-100 h-50" value={sex}
          onChange={(e) => setGender(e.target.value)} >
           <option value="">Select Gender</option>
          <option value="male">Male</option>
          <option value="female">Female</option>
        </select>
                </div>
                <div className="col-lg-12">
                  <button    onClick={calculateBMI} type="submit">Calculate</button>
                  {bmi && (
        <div className="mt-4 text-lg font-bold">
          <h2 style={{color:"white"}}>Your BMI: {bmi}</h2>
          <h3 style={{color:"white"}}>{message}</h3>
        </div>
      )}
      {/* style={{width:"260px",height:"45px"}} */}
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* BMI Calculator Section End */}
  {/* Get In Touch Section Begin */}
  <div className="gettouch-section">
    <div className="container">
      <div className="row">
        <div className="col-md-4">
          <div className="gt-text">
            <i className="fa fa-map-marker" />
            <p>
            Dasuya ,Distt: Hoshiarpur
            </p>
          </div>
        </div>
        <div className="col-md-4">
          <div className="gt-text">
            <i className="fa fa-mobile" />
            <ul>
            <li>81468XXXXX</li>
            <li>98779XXXXX</li>
            </ul>
          </div>
        </div>
        <div className="col-md-4">
          <div className="gt-text email">
            <i className="fa fa-envelope" />
            <p>kaurkiranjot47@gmail</p>
          </div>
        </div>
      </div>
    </div>
  </div>
  {/* Get In Touch Section End */}
 
  {/* Search model Begin */}
  <div className="search-model">
    <div className="h-100 d-flex align-items-center justify-content-center">
      <div className="search-close-switch">+</div>
      <form className="search-model-form">
        <input type="text" id="search-input" placeholder="Search here....." />
      </form>
    </div>
  </div>
  {/* Search model end */}
  {/* Js Plugins */}
</>

    )
}
