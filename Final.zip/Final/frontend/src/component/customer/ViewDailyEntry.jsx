import { Link } from "react-router-dom";
export default function ViewDailyEntry()
{
    return(
        <>
        <section
    className="breadcrumb-section set-bg"
    // data-setbg="assets/img/breadcrumb-bg.jpg"
    style={{backgroundImage:"url(/assets/img/breadcrumb-bg.jpg)"}}
  >
    <div className="container">
      <div className="row">
        <div className="col-lg-12 text-center">
          <div className="breadcrumb-text">
            <h2> Daily Entries</h2>
            <div className="bt-option">
              <Link to="/">Home</Link>
              {/* <Link to="/admin/trainerReq">TrainerRequest</Link> */}
              <span> DailyEntries</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Breadcrumb Section End */}

    {/*Table */}
    <div className ="container mt-4">
    <h3 className="fw-bold">Daily Entries</h3><br></br>
    <table className="table table-bordered table-striped">
        <thead className="thead-dark"
        // className="table-light"
        >
            <tr>
                
                <th>Name</th>
                <th>Workout</th>
                <th>Time</th>
                <th>Feedback</th>
                <th>Status</th>
                <th>Action
                    
                </th>
            </tr>
            </thead>
            <tbody>
                <tr>
                <td>1.</td>
                <td>abc</td>
                <td>xxx</td>
                <td>xxxxxxxx</td>
                <td>xx</td>
                <td>xx
                <div className="btn-group  ms-2">
                    <button  style={{color:"oranged"}}>Edit</button>
                    <button  style={{color:"oranged"}}>Delete</button>
                    </div>
                </td>
                
                </tr>
                <tr>
                <td>2.</td>
                <td>cde</td>
                <td>xyz</td>
                <td>xx</td>
                <td>xxx</td>
                <td>xx
                <div className="btn-group  ms-2">
                    <button  style={{color:"oranged"}}>Edit</button>
                    <button  style={{color:"oranged"}}>Delete</button>
                    </div>
                </td>
                
                </tr>
                <tr>
                <td>3.</td>
                <td>cde</td>
                <td>xyz</td>
                <td>xx</td>
                <td>xxx</td>
                <td>xx
                <div className="btn-group  ms-2">
                    <button  style={{color:"oranged"}}>Edit</button>
                    <button  style={{color:"oranged"}}>Delete</button>
                  
                    </div>
                </td>
               
                </tr>
                <tr>
                <td>4.</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
               
                </tr>
                </tbody> </table>
  </div>
        </>
    )
}