import React, { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from "react-router-dom";
import axios from 'axios';
import { toast } from 'react-toastify';

import {ClipLoader} from "react-spinners"
import ApiServices from '../layout/ApiServices';

const override= {

  margin: "0 auto",
  marginTop: "250px",
  marginBottom: '200px',
  display:'flex',
  justifyContent: 'center',
  alignItems: 'center',
  overflow:"hidden"
};

export default function SingleSession(){
  const [customerId, setCustomerId] = useState("")
  const [customerName, setCustomerName] = useState("")
  const [packageId, setPackageId] = useState("")
  const [trainerId, setTrainerId] = useState("")
  const [day1, setDay1] = useState()
  const [day2, setDay2] = useState()
  const [day3, setDay3] = useState()
  const [day4, setDay4] = useState()
  const [day5, setDay5] = useState()
  const [day6, setDay6] = useState()
  const [diet, setDiet] = useState()
  const [week, setWeek] = useState()
  // const [x, setX] = useState(false)
  let [color, setColor] = useState("#2c4964;");
const [isLoading, setIsLoading] = useState(true);

const param=useParams()
console.log(param);
const id=param.id 
const nav = useNavigate()


useEffect(()=>{
    let data={
        _id:id
        
    }
        ApiServices.SessionSingle(data).then((res)=>{
            console.log("Category result is :",res);   
            setCustomerId(res.data.data.customerId._id)
            setCustomerName(res.data.data.customerId.name)
            setWeek(res.data.data.week)
            setDiet(res.data.data.diet)
            setDay1(res.data.data.day1)
            setDay2(res.data.data.day2)
            setDay3(res.data.data.day3)
            setDay4(res.data.data.day4)
            setDay5(res.data.data.day5)
            setDay6(res.data.data.day6)
           
        }).catch((err)=>{
            console.log(err);
        })
        setTimeout(() => {
          setIsLoading(false);
        }, 1500);
   },[])

  const Submitted=(e)=>{
    e.preventDefault()
    let obj ={
      Authorization:sessionStorage.getItem("token")
    }
    console.log("obj is:",obj)
    let data={
    _id:id,
    customerId:customerId,
    trainerId:trainerId,
    week:week,
    diet:diet,
    day1:day1,  
    day2:day2,
    day3:day3,
    day4:day4,
    day5:day5,
    day6:day6,


    // price:price,
    // features:features
    }

    ApiServices.UpdateSession(data).then(
      (res)=>{
        
        if(res.data.success==true){
        console.log(res)
        toast.success(res.data.message);
        nav("/trainer/viewSession/"+id)

        
        } 
        else{
          toast.error(res.data.message)
        }
      }
     
    ).catch(
      (err)=>{
        console.log(err);
        toast.error(err.data.message)
      }
    )
// setX(false)
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    // Example format: "MM/DD/YYYY"
    const formattedDate = `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`;
    return formattedDate;
};
    return(
      <>
      <section
        className="breadcrumb-section set-bg"
        style={{ backgroundImage: "url(/assets/img/breadcrumb-bg.jpg)" }}
      >
        <div className="container">
          <div className="row">
            <div className="col-lg-12 text-center">
              <div className="breadcrumb-text">
                <h2>Assigned Trainer Diet + workout</h2>
                {/* <div className="bt-option">
                  <Link to="/">Home</Link>
                  <span>Diet</span>
                </div> */}
              </div>
            </div>
          </div> 
        </div>
      </section>
      {isLoading ? (
                <ClipLoader
                color={color}
                loading={isLoading}
                cssOverride={override}
                size={100}
                aria-label="Loading Spinner"
                data-testid="loader"
              />
      ) : (
        <section className="contact_section layout_padding">
        <div className="container">
          <div className="heading_container">
            <h2><span>Diet</span></h2>
          </div>
          <div className="loginbox mx-auto d-block col-lg-8 mt-5 mb-5">
                                    <div className="loginform p-4">
                  <form onSubmit={Submitted}>
                    <div className="form">
                    <div style={{ marginBottom: '20px' }}>
                      <h3 className='text-white'>Week: {formatDate(week)}</h3>
                    </div>
                      <label className="text-white form-label " style={{ marginLeft: "20px" }}>Week</label>
                      {/* <input className="w-100" type="date" placeholder="Enter Week" value={week} onChange={handleDateChange}  /> */}
                      <label className="text-white form-label " style={{ marginLeft: "20px" }}>Diet</label>
                      <input type="text" className="w-100" placeholder="Enter Diet" value={diet} onChange={(e) => setDiet(e.target.value)} required readOnly />
                   
                      <label className="text-white form-label " style={{ marginLeft: "20px" }}>Day1  </label>
                      <input type="text" className="w-100" placeholder="Enter Day1 Diet"  value={day1} onChange={(e) => setDay1(e.target.value)}  required  readOnly/>
                   
                   
                      <label className="text-white form-label " style={{ marginLeft: "20px" }}>Day2  </label>
                      <input type="text" className="w-100" placeholder="Enter Day2 Diet"  value={day2} onChange={(e) => setDay2(e.target.value)}  required  readOnly/>
                   
                   
                      <label className="text-white form-label " style={{ marginLeft: "20px" }}>Day3  </label>
                      <input type="text" className="w-100" placeholder="Enter Day3 Diet"  value={day3} onChange={(e) => setDay3(e.target.value)}  required readOnly/>
                   
                   
                      <label className="text-white form-label " style={{ marginLeft: "20px" }}>Day4  </label>
                      <input type="text" className="w-100" placeholder="Enter Day4 Diet"  value={day4} onChange={(e) => setDay4(e.target.value)}  required readOnly/>
                   
                   
                      <label className="text-white form-label " style={{ marginLeft: "20px" }}>Day5  </label>
                      <input type="text" className="w-100" placeholder="Enter Day5 Diet"  value={day5} onChange={(e) => setDay5(e.target.value)}  required readOnly/>
                   
                   
                      <label className="text-white form-label " style={{ marginLeft: "20px" }}>Day6  </label>
                      <input type="text" className="w-100" placeholder="Enter Day6 Diet"  value={day6} onChange={(e) => setDay6(e.target.value)}  required readOnly/>
                    </div>
                  </form>
                  
               </div>
               </div>
        </div>
      </section>
      
      )}
    </>
  );
};
 