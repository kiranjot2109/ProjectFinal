import { Link } from "react-router-dom";
import React, { useState } from "react";
// export default function ManageProfile(){
    const  ManageProfile = () => {
        const [formData, setFormData] = useState({
          fullName: "",
          email: "",
          phone: "",
          password: "",
          address: "",
          profilePicture: null,
        });
      
        const [errors, setErrors] = useState({});
        const [preview, setPreview] = useState(null);
      
        // Handle Input Change
        const handleChange = (e) => {
          const { name, value } = e.target;
          setFormData({ ...formData, [name]: value });
        };
      
        // Handle File Upload
        const handleFileChange = (e) => {
          const file = e.target.files[0];
          if (file) {
            setFormData({ ...formData, profilePicture: file });
      
            // Show preview
            const reader = new FileReader();
            reader.onloadend = () => {
              setPreview(reader.result);
            };
            reader.readAsDataURL(file);
          }
        };
      
        // Form Validation
        const validateForm = () => {
          let newErrors = {};
      
          if (!formData.fullName.trim()) newErrors.fullName = "Full Name is required";
          if (!formData.email.match(/^\S+@\S+\.\S+$/)) newErrors.email = "Invalid email";
          if (!formData.phone.match(/^\d{10}$/)) newErrors.phone = "Phone must be 10 digits";
          if (formData.password.length < 6) newErrors.password = "Password must be at least 6 characters";
          if (!formData.address.trim()) newErrors.address = "Address is required";
      
          setErrors(newErrors);
          return Object.keys(newErrors).length === 0;
        };
      
        // Handle Form Submission
        const handleSubmit = (e) => {
          e.preventDefault();
          if (validateForm()) {
            alert("Profile updated successfully!");
            console.log(formData);
          }
        }
    return(
        <>
          <section
    className="breadcrumb-section set-bg"
    // data-setbg="assets/img/breadcrumb-bg.jpg"
    style={{backgroundImage:"url(/assets/img/breadcrumb-bg.jpg)"}}
  >
    <div className="container">
      <div className="row">
        <div className="col-lg-12 text-center">
          <div className="breadcrumb-text">
            <h2>Managed Profile</h2>
            <div className="bt-option">
              <Link to="/">Home</Link>
              {/* <Link to="/admin/trainerReq">TrainerRequest</Link> */}
              <span>Managed Profile</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Breadcrumb Section End */}

{/* Form */}
<div className="container d-flex justify-content-center mt-5 ">
      <div className="card shadow w-50">
        <div className="card-header bg-primary text-white">
          <h4 style={{background:"oranged"}}>Manage Profile</h4>
        </div>
        <div className="card-body">
          <form onSubmit={handleSubmit}>
            
          

                <div className="row">
                  {/* Full Name */}
                  <div className="col-md-6 mb-3">
                    <label className="form-label">Full Name</label>
                    <input
                      type="text"
                      className={`form-control ${errors.fullName && "is-invalid"}`}
                      name="fullName"
                      value={formData.fullName}
                      onChange={handleChange}
                    />
                    {errors.fullName && <div className="invalid-feedback">{errors.fullName}</div>}
                  </div>

                  {/* Email */}
                  <div className="col-md-6">
                    <label className="form-label">Email</label>
                    <input
                      type="email"
                      className={`form-control ${errors.email && "is-invalid"}`}
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                    />
                    {errors.email && <div className="invalid-feedback">{errors.email}</div>}
                  </div>
                </div>

                <div className="row mt-3">
                  {/* Phone Number */}
                  <div className="col-md-6">
                    <label className="form-label">Phone</label>
                    <input
                      type="tel"
                      className={`form-control ${errors.phone && "is-invalid"}`}
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                    />
                    {errors.phone && <div className="invalid-feedback">{errors.phone}</div>}
                  </div>

                  {/* Password */}
                  <div className="col-md-6">
                    <label className="form-label">Password</label>
                    <input
                      type="password"
                      className={`form-control ${errors.password && "is-invalid"}`}
                      name="password"
                      value={formData.password}
                      onChange={handleChange}
                    />
                    {errors.password && <div className="invalid-feedback">{errors.password}</div>}
                  </div>
                </div>


                <div className="row mt-3">
                  {/* Profile Picture Upload */}
                  <div className="col-md-12">
                  <label className="form-label">Profile Picture</label>
                <input type="file" className="form-control" onChange={handleFileChange} />
                {preview && (
                  <img src={preview} alt="Profile Preview" className="img-thumbnail mt-2" width="150" />
                )}
              </div></div>
              
                <div className="row mt-3">
                  {/* Address */}
                  <div className="col-md-12">
                    <label className="form-label">Address</label>
                    <input
                      type="text"
                      className={`form-control ${errors.address && "is-invalid"}`}
                      name="address"
                      value={formData.address}
                      onChange={handleChange}
                    />
                    {errors.address && <div className="invalid-feedback">{errors.address}</div>}
                  </div>
                </div>

             


                <div className="row mt-3">
                  {/* Submit Button */}
                  <div className="col-md-12 text-end">
                    <button type="submit" className="btn btn-primary w-100">Save Changes</button><br></br>
                    <button type="reset" className="btn btn-primary  w-100 mt-3" onClick={() => setFormData({
                      fullName: "",
                      email: "",
                      phone: "",
                      password: "",
                      address: "",
                      profilePicture: null
                    })}>
                      Cancel
                    </button>
                  </div>
                </div>

             
         
          </form>
        </div>
      </div>
    </div>
        </>
    )
}

export default ManageProfile;