
import React, { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from "react-router-dom";

import { toast, ToastContainer } from 'react-toastify';
import {ClipLoader} from "react-spinners"
import ApiServices from '../layout/ApiServices';



const override= {

    margin: "0 auto",
    marginTop: "250px",
    marginBottom: '200px',
    display:'flex',
    justifyContent: 'center',
    alignItems: 'center',
    overflow:"hidden"
  };
export default function ViewSession() {
  const param=useParams()
  console.log(param);
  const id=param.id 
  console.log("Id is :",id)
  const [week, setWeek] = useState("")
  const [diet, setDiet] = useState()
  const [day1, setDay1] = useState()
  const [day2, setDay2] = useState()
  const [day3, setDay3] = useState()
  const [day4, setDay4] = useState()
  const [day5, setDay5] = useState()
  const [day6, setDay6] = useState()
  const [customerId, setCustomerId] = useState()
  const [customerName, setCustomerName] = useState()

  let [color, setColor] = useState("#2c4964;");
  const [isLoading, setIsLoading] = useState(true);

  const nav = useNavigate()


    useEffect(()=>{
      let data={
          _id:id
          
      }
          ApiServices.SessionSingle(data).then((res)=>{
              console.log("Category result is :",res);   
              setCustomerId(res.data.data.customerId._id)
              setCustomerName(res.data.data.customerId.name)
              setWeek(res.data.data.week)
              setDiet(res.data.data.diet)
              setDay1(res.data.data.day1)
              setDay2(res.data.data.day2)
              setDay3(res.data.data.day3)
              setDay4(res.data.data.day4)
              setDay5(res.data.data.day5)
              setDay6(res.data.data.day6)
             
          }).catch((err)=>{
              console.log(err);
          })
          setTimeout(() => {
            setIsLoading(false);
          }, 1500);
     },[])




    const formatDate = (dateString) => {
      const date = new Date(dateString);
      // Example format: "MM/DD/YYYY"
      const formattedDate = `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`;
      return formattedDate;
  };

    return(
      <>
      <ToastContainer position="top-right" autoClose={2000} />

<section
  className="breadcrumb-section set-bg"
  style={{ backgroundImage: "url(/assets/img/breadcrumb-bg.jpg)" }}
>
  <div className="container">
    <div className="row">
      <div className="col-lg-12 text-center">
        <div className="breadcrumb-text">
          <h2>View Session</h2>
          <div className="bt-option">
            <Link to="/">Home</Link>
            <span>View Session</span>
          </div>
        </div>
      </div>
    </div> 
  </div>
</section>
      {isLoading ? (
                <ClipLoader
                color={color}
                loading={isLoading}
                cssOverride={override}
                size={100}
                aria-label="Loading Spinner"
                data-testid="loader"
              />
      ) : (
        <section className="contact_section layout_padding">
        <div className="container">
          <div className="heading_container">
            <h2>
              <span>Single Session Loaded</span>
            </h2>
          </div>
          <div className='table-responsive'>
        <table className=" table table-hover table-striped table mt-5">
            <thead className="table-dark">
                <tr>
                    <th>Customer Name</th>
                    <th>week</th>
                    <th>Diet</th>
                    <th>Day 1</th>
                    <th>Day 2</th>
                    <th>Day 3</th>
                    <th>Day 4</th>
                    <th>Day 5</th>
                    <th>Day 6</th>
                    <th>Action</th>

                </tr>
            </thead>
            <tbody >
                <tr >
                    <td>{customerName}</td>
                    <td>{formatDate(week)}</td>
                    <td>{diet}</td>
                    <td>{day1}</td>
                    <td>{day2}</td>
                    <td>{day3}</td>
                    <td>{day4}</td>
                    <td>{day5}</td>
                    <td>{day6}</td>


                    <td>
                      <Link to={"/trainer/updateSession/"+id}>
                      <button className='btn' type='submit' style={{backgroundColor:'#22A699'}}>
                     Update Session
                    </button>
                    </Link>
                    </td>
                </tr>
            </tbody>
        </table></div>
        </div>
        </section>
      )}
    </>
  );
};
 