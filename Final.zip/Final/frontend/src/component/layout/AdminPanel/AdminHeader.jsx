import { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";

export default function AdminHeader(){
  const navigate = useNavigate();
  const nav=useNavigate()
  useEffect(()=>{
     var userType = sessionStorage.getItem("userType")
     if(userType != 1){
      toast.error("Please Login first!!")
      nav("/login")
     }
  },[])
  const logout=()=>{
      sessionStorage.clear()
      toast.success("Logout successfully")
      setTimeout(()=>{
         nav("/login")

      },3000)
  }
    return(
        <>
        {/* Header Section Begin */}
        <header className="header-section">
          <div className="container-fluid">
            <ToastContainer/>
            <div className="row">
              <div className="col-lg-3">
              <h3 style={{color:"white",fontWeight:"bold",fontSize:"45px"}}> STRENGTH</h3>
                <div className="logo">
                  <a href="/">
                    <img src="/assets/img/logo.png" alt="" />
                  </a>
                </div>
              </div>
              <div className="col-lg-7">
                <nav className="nav-menu">
                  <ul>
                    <li className="active">
                      <Link to="/admin">Home</Link>
                    </li>
                    <li>
                    <Link to="#">Package</Link>
                      <ul className="dropdown">
                        <li>
                        <Link to="/admin/AddPackage">Add </Link>
                        </li>
                        <li>
                        <Link to="/admin/ManagePackage">Manage</Link>
                        </li>
                       
                      </ul>
                    </li>
                    <li>
                    <Link to="#">Trainer</Link>
                      <ul className="dropdown">
                        <li>
                        <Link to="/admin/AddTrainer">Add </Link>
                        </li>
                        <li>
                        <Link to="/admin/ManageTrainer">Manage</Link>
                        </li>
                       
                      </ul>
                    </li>
                    <li>
                      <Link to="/admin/Requests">Request</Link>
                    </li>
                    <li>
                      <Link to="/admin/ManageMembers">Members</Link>
                    </li>
                    <li>
                      <Link to="/admin/AllReports">Reports</Link>
                    </li>
                    {/* <li>
                      <Link to="/admin/changepass">Change Password</Link>
                    </li> */}
                    {/* <li>
                      <Link to="/admin/manageprofile">Managed Profile</Link>
                    </li> */}
                    {/* <li>
                      <Link to="/admin/dailyEntry">Daily Entries</Link>
                    </li> */}
                    <li>
                      <Link to="/admin/queries">Queries</Link>
                    </li>
                  
                    {/* <li>
                      <Link to="/admin/queries">Logout</Link>
                    </li> */}
                    
                   
             
                    {/* <li>
                      <Link to="/contact">Contact</Link>
                    </li> */}
                  </ul>
                </nav>
              </div>
              <div className="col-lg-2">
              <button className="btn btn-danger"style={{ backgroundColor: "orangered", padding: "5px,10px", borderRadius: "10px", color: "white", fontSize: "15px" }}  onClick={logout}>Logout</button>
                
              </div>
            </div>
            <div className="canvas-open">
              <i className="fa fa-bars" />
            </div>
          </div>
        </header>
        {/* Header End */}
      </>
    )
}