import { Link, useNavigate } from "react-router-dom";

import { useState, useEffect } from "react";
import { toast, ToastContainer } from "react-toastify";
import ClipLoader from "react-spinners/ClipLoader";
import "react-toastify/dist/ReactToastify.css";
import ApiServices from "../ApiServices";

const override= {
    margin: "0 auto",
    marginTop: "250px",
    marginBottom: '200px',
    display:'flex',
    justifyContent: 'center',
    alignItems: 'center',
    overflow:"hidden"
  };
export default function ManageTrainers() {
    const nav=useNavigate()  //hook must be called outside function
    const [x,setX]=useState(false)
    const [data,setData]=useState([])
    const [name,setName]=useState("")
    const [image,setImage]=useState({})
    const [imageName,setImageName]=useState("")
    let [color, setColor] = useState("#2c4964;");
    const [isLoading, setIsLoading] = useState(true);
    const [modalShow, setModalShow] = useState(false);

    useEffect(()=>{
        ApiServices.GetAllTranier().then((res)=>{

          console.log("Result is",res)
          // console.log(res.data.data)
          setData(res.data.data)
          // setSpecialist(res.data.data)
      })
        .catch((err)=>{console.log(err)})
        setTimeout(() => {
          setIsLoading(false);
        }, 1500);
      },[x])

      const changeStatus=(id,status)=>{
        let data = {
            _id:id,
            status:status
        }
        ApiServices.changeStatusTrainer(data)
        .then((res)=>{
            if(res.data.success){
                toast.success(res.data.message)
                setX(true)
            }
            else{
                toast.error(res.data.message)
                setX(true)

            }
            // window.location.reload()
        })
        setX(false)
    }
  return (
    <>
      <ToastContainer position="top-right" autoClose={2000} />

      <section
        className="breadcrumb-section set-bg"
        style={{ backgroundImage: "url(/assets/img/breadcrumb-bg.jpg)" }}
      >
        <div className="container">
          <div className="row">
            <div className="col-lg-12 text-center">
              <div className="breadcrumb-text">
                <h2>Manage Trainers</h2>
                <div className="bt-option">
                  <Link to="/">Home</Link>
                  <span>Manage Trainers</span>
                </div>
              </div>
            </div>
          </div> 
        </div>
      </section>
      <>
        {isLoading &&(
            <ClipLoader
            color={color}
            loading={isLoading}
            cssOverride={override}
            size={100}
            aria-label="Loading Spinner"
            data-testid="loader"
          />
          )}
          {!isLoading &&(
        <>
        <section className="contact_section layout_padding">
        <div className="container">
          <div className="heading_container">
            
            {/* <Link className="nav-link col-1" to="/admin/addtrainer">
                <button type="button" class="btn btn-primary btn-lg mx-5">Add</button>
            </Link> */}
          </div>
          <div className='table-responsive'>
          <table className=" table table-hover table-striped table mt-5">
            <thead className="table-dark">
                <tr>
                    <th>Sr.No</th>
                    <th>Name</th>
                    <th>Profile</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th>Address</th>
                    <th>Experience</th>
                    <th>Status</th>
                    <th>Edit</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody >
            {data?.map(
                (el,index)=>(
                <tr >
                    <td>{index+1}</td>
                    <td>{el?.name}</td>
                    <td>
                            <img src={el?.profile} style={{height:"100px",width:"100px"}}/>
                    </td>
                    <td>{el?.email}</td>
                    <td>{el?.contact}</td>
                    <td>{el?.address}</td>
                    <td>{el?.experience}</td>
                    <td>{el.status?"true":"false"}</td>
                    
                    <td>
                      <Link to={"/admin/editTrainers/"+el?.userId?._id} >
                    <button className='btn text-light' style={{backgroundColor:'#219C90'}}>
                    Edit
                      
                    </button></Link></td>
                    <td> 
                      <>
                      {el.status === true && (
                       
                        <button className="btn text-center text-light" style={{backgroundColor:"crimson"}} onClick={()=>{changeStatus(el?._id,false)}}>Disable</button>
                        )}

                       {el.status === false && (
                        <button className="btn text-center text-light" style={{backgroundColor:"rgba(41, 171, 135)"}} onClick={()=>{changeStatus(el?._id,true)}}>Enable</button>
                        )}
                          </>
                    </td>
                </tr>
                ))}
            </tbody>
        </table>
        </div>
        </div>
        </section>
       
          </>
        )} 
        </>
    </>
  );
}
