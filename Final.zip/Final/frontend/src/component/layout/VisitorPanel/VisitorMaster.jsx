import { Outlet } from "react-router-dom";
import VisitorHeader from "./VisitorHeader";
import VisitorFooter from "./VisitorFooter";
import { ToastContainer } from "react-toastify";

export default function VisitorMaster (){
    return(
        <>
        <VisitorHeader/>
        <ToastContainer/>
        <Outlet/>
        <VisitorFooter/>
        </>
    )
}