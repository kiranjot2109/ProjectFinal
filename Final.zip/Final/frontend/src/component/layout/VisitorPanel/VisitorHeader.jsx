import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

export default function 
VisitorHeader (){
  const authenticate = sessionStorage.getItem('token')
  console.log(authenticate)
  const nav = useNavigate()
  const logout=()=>{
    sessionStorage.clear()
    toast.success("Logout successfully")
    setTimeout(()=>{
    nav("/login")

    })
  }

    return(
        <>
        {/* Header Section Begin */}
        <header className="header-section">
          <div className="container-fluid">
            <div className="row">
              <div className="col-lg-3">
              <h3 style={{color:"white",fontWeight:"bold",fontSize:"45px"}}> STRENGTH</h3>
                <div className="logo">
                  <a href="/">
                    <img src="/assets/img/logo.png" alt="" />
                  </a>
                </div>
              </div>
              <div className="col-lg-6">
                <nav className="nav-menu">
                  <ul>
                    <li className="active">
                      <Link to="/trainer">Home</Link>
                    </li>
                    <li>
                      <Link to="/services">Services</Link>
                    </li>
                    <li>
                      <Link to="/Gallery">Gallery</Link>
                    </li>
                    <li>
                      <Link to="/about-us">About Us</Link>
                    </li>
                  
                    {
                       authenticate != null ?
                     <>
                          <li>
                            <Link to="/Sessions">Session</Link>
                          </li>
                          <li>
                            <Link to="/contact">Query</Link>
                          </li>
                          <li>
                            <Link to="/mybookings">Bookings</Link>
                          </li>
                     
                     </>
                       :  
                       <>
                          <li>
                          <Link to="/login">Login</Link>
                        </li>
                        <li>
                          <Link to="/register">Register</Link>
                        </li>
                       
                       </>
                    }
                 

                    {/* <li>
                    <Link to="#">Pages</Link>
                      <ul className="dropdown">
                        <li>
                        <Link to="/about-us">About Us</Link>
                        </li>
                        <li>
                        <Link to="/ClassTimetable">Classes timetable</Link>
                        </li>
                        <li>
                          <Link to="/BmiCalculator">Bmi calculate</Link>
                        </li>
                        <li>
                        <Link to="/team">Our Team</Link>
                        </li>
                        <li>
                          <Link to="/Gallery">Gallery</Link>
                        </li>
                        <li>
                          <Link to="/Blog">Our blog</Link>
                        </li>
                        <li>
                          <Link to="/404">404</Link>
                        </li>
                      </ul>
                    </li> */}
                    {/* <li>
                      <Link to="/contact">Contact</Link>
                    </li> */}
                  </ul>
                </nav>
              </div>
              <div className="col-lg-2">
                <div className="top-option">
                {
                      authenticate != null ?
                      <li>

                        <Link className="btn btn-danger px-4 mb-4 me-4"style={{ backgroundColor: "orangered", padding: "5px,10px", borderRadius: "10px", color: "white", fontSize: "15px" }}  onClick={logout}>Logout</Link>

                      </li>:
                      ""

                    }
                </div>
              </div>
            </div>
            <div className="canvas-open">
              <i className="fa fa-bars" />
            </div>
          </div>
        </header>
        {/* Header End */}
      </>
    )
}