import { Outlet } from "react-router-dom";
import TrainerHeader from "./TrainerHeader";
import TrainerFooter from "./TrainerFooter";
import { ToastContainer } from "react-toastify/unstyled";

export default function TrainerMaster (){
    return(
        <>
        <TrainerHeader/>
        <ToastContainer/>
        <Outlet/>
        <TrainerFooter/>
        </>
    )
}