import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import ApiServices from "./layout/ApiServices";
import { ClipLoader } from "react-spinners";

const override= {

  margin: "0 auto",
  marginTop: "250px",
  marginBottom: '200px',
  display:'flex',
  justifyContent: 'center',
  alignItems: 'center',
  overflow:"hidden"
};
export default function Admin() {
  const [isLoading, setIsLoading] = useState(true);
  const [trainers,setTrainers]=useState([])
  const [members,setMembers]=useState([])
  const [bookings,setBookings]=useState([])
  const [packages,setPackages]=useState([])
  let [color, setColor] = useState("#2c4964");

  useEffect(()=>{
      let data = {
          status:sessionStorage.getItem.data
      }
      ApiServices.DashboardApi(data)
      .then((res)=>{
          console.log(res)

          setTrainers(res.data.totalTrainers)
          setMembers(res.data.totalMembers)
          setBookings(res.data.totalPackage)
          setPackages(res.data.totalBooking)


          
      }).catch((err)=>{
          console.log(err);
      })
      setTimeout(() => {
        setIsLoading(false);
      }, 1500);
  },[])
  return (
    <>
      <section
        className="breadcrumb-section set-bg"
        data-setbg="assets/img/breadcrumb-bg.jpg"
        style={{ backgroundImage: "url(assets/img/breadcrumb-bg.jpg)" }}
      >
        <div className="container">
          <div className="row">
            <div className="col-lg-12 text-center">
              <div className="breadcrumb-text">
                <h2>ADMIN</h2>
                <div className="bt-option">
                  <Link to="/">Home</Link>
                  <Link to="/admin">Admin</Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="choseus-section spad">
      <div className="container">
      {isLoading &&(
        <ClipLoader
        color={color}
        loading={isLoading}
        cssOverride={override}
        size={100}
        aria-label="Loading Spinner"
        data-testid="loader"
      />
      )}
        {!isLoading &&(
        <>
            <div className="container-fluid p-5">
                <div className="row d-flex justify-content-center">
                   
                    <div className="col-md-4 m-3">
                        <div className="card bg-warning" >
                            <img src="/assets/img/s-1.jpg" className="card-img-top"/>
                            <h2 className="text-center">Total Members</h2>
                            <h3 className="text-center">{members}</h3>
                        </div>
                    </div>
                    <div className="col-md-4 m-3">
                        <div className="card bg-warning" >
                            <img src="/assets/img/s-2.jpg"  className="card-img-top"/>
                            <h2 className="text-center">Packages</h2>
                            <h3 className="text-center">{packages}</h3>
                        </div>
                    </div>
                    <div className="col-md-4 m-3">
                        <div className="card bg-warning" >
                            <img src="/assets/img/s-3.jpg"  className="card-img-top"/>
                            <h2 className="text-center">Trainers</h2>
                            <h3 className="text-center">{trainers}</h3>
                        </div>
                    </div>
                    <div className="col-md-4 m-3">
                        <div className="card bg-warning" >
                            <img src="/assets/img/s-4.jpg"  className="card-img-top"/>
                            <h2 className="text-center">Bookings</h2>
                            <h3 className="text-center">{bookings}</h3>
                        </div>
                    </div>
                </div>
            </div>
        </>
            )}
        </div>
        </section>

    </>
  )
}