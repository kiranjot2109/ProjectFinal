import { Link } from "react-router-dom";

export default function OurTeam(){
    return(
        <>
        {/* Breadcrumb Section Begin */}
        <section
          className="breadcrumb-section set-bg"
          data-setbg="/assets/img/breadcrumb-bg.jpg"
          style={{backgroundImage:"url(assets/img/breadcrumb-bg.jpg)"}}
        >
          <div className="container">
            <div className="row">
              <div className="col-lg-12 text-center">
                <div className="breadcrumb-text">
                  <h2>Our Team</h2>
                  <div className="bt-option">
                    <Link to="/">Home</Link>
                    <span>Our team</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* Breadcrumb Section End */}
        {/* Team Section Begin */}
        <section className="team-section team-page spad">
          <div className="container">
            <div className="row">
              <div className="col-lg-12">
                <div className="team-title">
                  <div className="section-title">
                    <span>Our Team</span>
                    <h2>TRAIN WITH EXPERTS</h2>
                  </div>
                  <a href="#" className="primary-btn btn-normal appoinment-btn">
                    appointment
                  </a>
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col-lg-4 col-sm-6">
                <div className="ts-item set-bg" data-setbg="/assets/img/team/team-1.jpg" style={{backgroundImage:"url(/assets/img/team/team-1.jpg)"}}>
                  <div className="ts_text">
                    <h4>Athart Rachel</h4>
                    <span>Gym Trainer</span>
                    <div className="tt_social">
                      <a href="#">
                        <i className="fa fa-facebook" />
                      </a>
                      <a href="#">
                        <i className="fa fa-twitter" />
                      </a>
                      <a href="#">
                        <i className="fa fa-youtube-play" />
                      </a>
                      <a href="#">
                        <i className="fa fa-instagram" />
                      </a>
                      <a href="#">
                        <i className="fa  fa-envelope-o" />
                      </a>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-4 col-sm-6">
                <div className="ts-item set-bg" data-setbg="/assets/img/team/team-2.jpg" style={{backgroundImage:"url(/assets/img/team/team-2.jpg)"}}>
                  <div className="ts_text">
                    <h4>Athart Rachel</h4>
                    <span>Gym Trainer</span>
                    <div className="tt_social">
                      <a href="#">
                        <i className="fa fa-facebook" />
                      </a>
                      <a href="#">
                        <i className="fa fa-twitter" />
                      </a>
                      <a href="#">
                        <i className="fa fa-youtube-play" />
                      </a>
                      <a href="#">
                        <i className="fa fa-instagram" />
                      </a>
                      <a href="#">
                        <i className="fa  fa-envelope-o" />
                      </a>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-4 col-sm-6">
                <div className="ts-item set-bg" data-setbg="/assets/img/team/team-3.jpg" style={{backgroundImage:"url(/assets/img/team/team-3.jpg)"}}>
                  <div className="ts_text">
                    <h4>Athart Rachel</h4>
                    <span>Gym Trainer</span>
                    <div className="tt_social">
                      <a href="#">
                        <i className="fa fa-facebook" />
                      </a>
                      <a href="#">
                        <i className="fa fa-twitter" />
                      </a>
                      <a href="#">
                        <i className="fa fa-youtube-play" />
                      </a>
                      <a href="#">
                        <i className="fa fa-instagram" />
                      </a>
                      <a href="#">
                        <i className="fa  fa-envelope-o" />
                      </a>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-4 col-sm-6">
                <div className="ts-item set-bg" data-setbg="/assets/img/team/team-4.jpg" style={{backgroundImage:"url(/assets/img/team/team-4.jpg)"}}>
                  <div className="ts_text">
                    <h4>Athart Rachel</h4>
                    <span>Gym Trainer</span>
                    <div className="tt_social">
                      <a href="#">
                        <i className="fa fa-facebook" />
                      </a>
                      <a href="#">
                        <i className="fa fa-twitter" />
                      </a>
                      <a href="#">
                        <i className="fa fa-youtube-play" />
                      </a>
                      <a href="#">
                        <i className="fa fa-instagram" />
                      </a>
                      <a href="#">
                        <i className="fa  fa-envelope-o" />
                      </a>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-4 col-sm-6">
                <div className="ts-item set-bg" data-setbg="/assets/img/team/team-5.jpg" style={{backgroundImage:"url(/assets/img/team/team-5.jpg)"}}>
                  <div className="ts_text">
                    <h4>Athart Rachel</h4>
                    <span>Gym Trainer</span>
                    <div className="tt_social">
                      <a href="#">
                        <i className="fa fa-facebook" />
                      </a>
                      <a href="#">
                        <i className="fa fa-twitter" />
                      </a>
                      <a href="#">
                        <i className="fa fa-youtube-play" />
                      </a>
                      <a href="#">
                        <i className="fa fa-instagram" />
                      </a>
                      <a href="#">
                        <i className="fa  fa-envelope-o" />
                      </a>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-4 col-sm-6">
                <div className="ts-item set-bg" data-setbg="/assets/img/team/team-6.jpg" style={{backgroundImage:"url(/assets/img/team/team-6.jpg)"}}> 
                  <div className="ts_text">
                    <h4>Athart Rachel</h4>
                    <span>Gym Trainer</span>
                    <div className="tt_social">
                      <a href="#">
                        <i className="fa fa-facebook" />
                      </a>
                      <a href="#">
                        <i className="fa fa-twitter" />
                      </a>
                      <a href="#">
                        <i className="fa fa-youtube-play" />
                      </a>
                      <a href="#">
                        <i className="fa fa-instagram" />
                      </a>
                      <a href="#">
                        <i className="fa  fa-envelope-o" />
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* Team Section End */}
        {/* Get In Touch Section Begin */}
        <div className="gettouch-section">
          <div className="container">
            <div className="row">
              <div className="col-md-4">
                <div className="gt-text">
                  <i className="fa fa-map-marker" />
                  <p>
                  Dasuya ,Distt: Hoshiarpur
                  </p>
                </div>
              </div>
              <div className="col-md-4">
                <div className="gt-text">
                  <i className="fa fa-mobile" />
                  <ul>
                  <li>81468XXXXX</li>
                  <li>98779XXXXX</li>
                  </ul>
                </div>
              </div>
              <div className="col-md-4">
                <div className="gt-text email">
                  <i className="fa fa-envelope" />
                  <p>kaurkiranjot47@gmail</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Get In Touch Section End */}
        
        {/* Search model Begin */}
        <div className="search-model">
          <div className="h-100 d-flex align-items-center justify-content-center">
            <div className="search-close-switch">+</div>
            <form className="search-model-form">
              <input type="text" id="search-input" placeholder="Search here....." />
            </form>
          </div>
        </div>
        {/* Search model end */}
        {/* Js Plugins */}
      </>
         
    )
}