import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import ApiServices from "./layout/ApiServices";
import { toast, ToastContainer } from "react-toastify";
import { ClipLoader } from "react-spinners";
export default function Register() {
    const navigate = useNavigate();
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState()
    const [address, setAddress] = useState()
    const [gender, setGender] = useState()
    const [name, setName] = useState()
    const[image,setImage]=useState("")
    const[imageName,setImageName]=useState("")
    const [contact, setContact] = useState()
    const[load,setLoad]=useState(false)
  
        
    const nav = useNavigate()
    const changeImage=(e)=>{
      console.log(e.target.files[0]);
      setImage(e.target.files[0])
      setImageName(e.target.value)
    }
  
  
    const Submitted = (e) => { 
      e.preventDefault()
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      const contactPattern = /^[6-9]{1}[0-9]{9}$/;
      if (!emailPattern.test(email)) {
          toast.error("Invalid Email Format");
          return;
      }
      if (!contactPattern.test(contact)) {
          toast.error("Invalid Contact Format");
          return;
      }
      setLoad(true)
      console.log(e)
      let data =new FormData
        data.append("name",name)
        data.append("email",email)
        data.append("contact",contact)
        data.append("address",address)
        data.append("profile",image)
        data.append("password",password)
        data.append("gender",gender)    
      ApiServices.RegisterCustomer(data)
      .then((res) => { 
        console.log(res)
        if(res.data.success == true){
          toast.success(res.data.message);
          setTimeout(()=>{
            setLoad(false)
            nav("/login")

          },4000)
          setContact("");
          setEmail("");
          setPassword("");
          setName("");
          
        }
        else{
          setLoad(false)

          toast.error(res.data.message)
        }
      }
  )
  }
    return (
        <>
          {/* Breadcrumb Section Begin */}
  <section
    className="breadcrumb-section set-bg"
    data-setbg="assets/img/breadcrumb-bg.jpg"
    style={{backgroundImage:"url(assets/img/breadcrumb-bg.jpg)"}}

  >
    <div className="container">
      <div className="row">
        <div className="col-lg-12 text-center">
          <div className="breadcrumb-text">
            <h2>Registeration </h2>
            <div className="bt-option">
              <Link to="/">Home</Link>
              <a href="/">Pages</a>
              <span>Registeration </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Breadcrumb Section End */}
            <div className="container-fluid">
                <div className="row justify-content-center">
                           <ToastContainer/>
                           <ClipLoader loading={load} size={"100px"} />
                           {
                            !load?
                    <div className="loginbox mx-auto d-block col-lg-6 mt-5 mb-5">
                        <div className="loginform p-4">
                            <h2 className="text-center mb-4" style={{ marginLeft: "20px" }}>
                                Registeration Form
                            </h2>

                <form onSubmit={Submitted}>
              <div className="row g-3">
                <div className="col-md-12">
                  <div className="form-floating">
                    <label htmlFor="" className="text-white">Image</label>
                    <input
                      type="file"
                      className="form-control"
                      id="profile"
                      placeholder="Your profile"
                      onChange={changeImage} 
                    />
                  </div>
                </div>
                <div className="col-md-12 mt-4">
                  <div className="form-floating">
                  <label htmlFor="" className="text-white">Name</label>
                    <input
                      type="text"
                      className="form-control"
                      id="name"
                      placeholder="Your name"
                      value={name} 
                      onChange={(e) => { setName(e.target.value) }}
                    />
                  </div>
                </div>
                <div className="col-md-12 mt-4">
                  <div className="form-floating">
                  <label htmlFor="" className="text-white">Email</label>
                    <input
                      type="email"
                      className="form-control"
                      id="email"
                      placeholder="Your Email"
                      value={email} 
                      onChange={(e) => { setEmail(e.target.value) }}
                    />
                  </div>
                </div>
                <div className="col-md-12 mt-4">
                  <div className="form-floating">
                  <label htmlFor="" className="text-white">Contact</label>
                    <input
                      type="tel"
                      className="form-control"
                      id="contact"
                      placeholder="Your contact"
                      value={contact} 
                      maxLength={10} 
                      minLength={10} 
                      onChange={(e) => { setContact(e.target.value) }}
                    />
                  </div>
                </div>
                <div className="col-md-12 mt-4">
                  <div className="form-floating">
                  <label htmlFor="" className="text-white">Address</label>
                    <input
                      type="text"
                      className="form-control"
                      id="address"
                      placeholder="Your Address"
                      value={address} 
                      onChange={(event) => { setAddress(event.target.value) }}
                    />
                  </div>
                </div>
                <label htmlFor="gender " className="m-4 text-white" style={{color:"grey"}}>Select Gender:</label>
                  <div className="form-check m-4">
                    <input 
                      className="form-check-input" 
                      type="radio" 
                      name="gender" 
                      id="male" 
                      value="male" 
                      onClick={(e) => { setGender(e.target.value) }}
                    />
                    <label className="form-check-label text-white" htmlFor="male" >Male</label>
                  </div>
                  <div className="form-check mt-4">
                    <input 
                      className="form-check-input" 
                      type="radio" 
                      name="gender" 
                      id="female" 
                      value="female" 
                      onClick={(e) => { setGender(e.target.value) }}
                    />
                    <label className="form-check-label text-white" htmlFor="female">Female</label>
                  </div>
                <div className="col-md-12 mt-4">
                  <div className="form-floating">
                  <label htmlFor="" className="text-white">Password</label>
                    <input
                      type="password"
                      className="form-control"
                      id="password"
                      placeholder="Your Password"
                      value={password} 
                      onChange={(event) => { setPassword(event.target.value) }}
                    />
                  </div>
                </div>
                <div className="col-12 text-center">
                  <button className="btn btn-primary py-3 px-5 mt-4" type="submit">Register</button>
                </div>
              </div>
            </form>
                        </div>
                    </div>:""
                           }
                </div>
            </div>

        </>
    );
}