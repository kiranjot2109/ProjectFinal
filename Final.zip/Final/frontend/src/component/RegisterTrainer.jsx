import { Link } from "react-router-dom";
import { useState } from "react";
import ApiServices from "./layout/ApiServices";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { ClipLoader } from "react-spinners";
import { useNavigate } from "react-router-dom";

export default function RegisterTrainer() {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [experience, setExperience] = useState("");
    const [contact, setContact] = useState("");
    const [address, setAddress] = useState("");
    const [profile, setProfile] = useState("");
    const [loading, setLoading] = useState(false);
    const [message, setMessage] = useState("");
    const nav=useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();

        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const passwordPattern = /[1-9]/;
        if (!emailPattern.test(email)) {
            toast.error("Invalid Email Format");
            return;
        }

        if (!passwordPattern.test(password)) {
            toast.error("Password must be at least 8 characters with uppercase, lowercase, number & special character");
         return;
        }

        if (!profile) {
            toast.error("Profile Image is Required");
            return;
        }

        setLoading(true);

        const formData = new FormData();
        formData.append("name", name);
        formData.append("email", email);
        formData.append("password", password);
        formData.append("contact", contact);
        formData.append("experience", experience);
        formData.append("address", address);
        formData.append("profile", profile);

        ApiServices.RegisterTrainer(formData)
            .then((res) => {
                setLoading(false);
                setMessage(res.data.message);
                toast.success("Request Submitted Successfully");
                // clear form
                setName(""); setEmail(""); setPassword(""); setContact("");
                setExperience(""); setAddress(""); setProfile("");
                setTimeout(()=>{
                    nav("/")
                },2000)
            })
            .catch(() => {
                setLoading(false);
                toast.error("Something went wrong!");
            });
    };

    return(
        <>
            <ToastContainer />
            <section className="breadcrumb-section set-bg"
                data-setbg="assets/img/breadcrumb-bg.jpg"
                style={{ backgroundImage: "url(assets/img/breadcrumb-bg.jpg)" }}>
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12 text-center">
                            <div className="breadcrumb-text">
                                <h2>FILL BELOW FORM TO MAKE REQUEST</h2>
                                <div className="bt-option">
                                    <Link to="/">Home</Link>
                                    <span>Register As Trainer</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <div className="container-fluid">
                <div className="row justify-content-center">
                    <div className="loginbox mx-auto d-block col-lg-4 mt-5 mb-5">
                        <div className="loginform p-4">
                            <h2 className="text-center mb-4" style={{ marginLeft: "20px" }}>
                                Make Request For Registration
                            </h2>

                            {message && (
                                <div className="alert alert-success text-center w-100" style={{marginLeft:"5rem"}}>
                                    {message}
                                </div>
                            )}

                            <form onSubmit={handleSubmit}>
                                <div className="form">
                                   <label className="text-white form-label " style={{marginLeft:"20px"}}>Name</label><input type="text" placeholder="Enter Name" value={name} onChange={(e) => setName(e.target.value)} required />
                                   <label className="text-white form-label " style={{marginLeft:"20px"}}>Email</label><input type="email" placeholder="Enter Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                                   <label className="text-white form-label " style={{marginLeft:"20px"}}>Address</label><input type="text" placeholder="Enter Address" value={address} onChange={(e) => setAddress(e.target.value)} required />
                                   <label className="text-white form-label " style={{marginLeft:"20px"}}>Experience</label><input type="text" placeholder="Experience (e.g. 5 Years)" value={experience} onChange={(e) => setExperience(e.target.value)} required />
                                   <label className="text-white form-label " style={{marginLeft:"20px"}}>Image</label> <input type="file" className="bg-light" onChange={(e) => setProfile(e.target.files[0])} required />
                                   <label className="text-white form-label " style={{marginLeft:"20px"}}>Contact</label> <input type="number" placeholder="Enter Contact Number" value={contact} onChange={(e) => setContact(e.target.value)} required />
                                   <label className="text-white form-label " style={{marginLeft:"20px"}}>Password</label>  <input type="password" placeholder="Enter Password Here" value={password} onChange={(e) => setPassword(e.target.value)} required />

                                    <button type="submit" className="btn2 mt-3" disabled={loading}>
                                        {loading ? <ClipLoader size={20} color="#fff" /> : "Register"}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
