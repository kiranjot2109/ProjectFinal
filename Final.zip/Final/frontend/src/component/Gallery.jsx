import { Link } from "react-router-dom";
export default function Gallery(){
    return(
        <>
  {/* Breadcrumb Section Begin */}
  <section
    className="breadcrumb-section set-bg"
    data-setbg="assets/img/breadcrumb-bg.jpg"
    style={{backgroundImage:"url(assets/img/breadcrumb-bg.jpg)"}}

  >
    <div className="container">
      <div className="row">
        <div className="col-lg-12 text-center">
          <div className="breadcrumb-text">
            <h2>Gallery</h2>
            <div className="bt-option">
              <Link to="/">Home</Link>
              <a href="/">Pages</a>
              <span>Gallery</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Breadcrumb Section End */}
  {/* Gallery Section Begin */}
  <div className="gallery-section gallery-page">
    <div className="gallery">
      <div className="grid-sizer" />
      <div
        className="gs-item grid-wide set-bg"
        data-setbg="assets/img/gallery/gallery-1.jpg"
     style={{backgroundImage:"url(assets/img/gallery/gallery-1.jpg)"}}

      >
        <a href="assets/img/gallery/gallery-1.jpg" className="thumb-icon image-popup">
          <i className="fa fa-picture-o" />
        </a>
      </div>
      <div className="gs-item set-bg" data-setbg="assets/img/gallery/gallery-2.jpg"   style={{backgroundImage:"url(assets/img/gallery/gallery-2.jpg)"}} >
        <a href="assets/img/gallery/gallery-2.jpg" className="thumb-icon image-popup">
          <i className="fa fa-picture-o" />
        </a>
      </div>
      <div className="gs-item set-bg" data-setbg="assets/img/gallery/gallery-3.jpg"   style={{backgroundImage:"url(assets/img/gallery/gallery-3.jpg)"}}>
        <a href="assets/img/gallery/gallery-3.jpg" className="thumb-icon image-popup">
          <i className="fa fa-picture-o" />
        </a>
      </div>
      <div className="gs-item set-bg" data-setbg="assets/img/gallery/gallery-4.jpg"   style={{backgroundImage:"url(assets/img/gallery/gallery-4.jpg)"}}>
        <a href="assets/img/gallery/gallery-4.jpg" className="thumb-icon image-popup">
          <i className="fa fa-picture-o" />
        </a>
      </div>
      <div className="gs-item set-bg" data-setbg="assets/img/gallery/gallery-5.jpg"   style={{backgroundImage:"url(assets/img/gallery/gallery-5.jpg)"}}>
        <a href="assets/img/gallery/gallery-5.jpg" className="thumb-icon image-popup">
          <i className="fa fa-picture-o" />
        </a>
      </div>
      <div
        className="gs-item grid-wide set-bg"
        data-setbg="assets/img/gallery/gallery-6.jpg"
        style={{backgroundImage:"url(assets/img/gallery/gallery-6.jpg)"}}
      >
        <a href="assets/img/gallery/gallery-6.jpg" className="thumb-icon image-popup">
          <i className="fa fa-picture-o" />
        </a>
      </div>
      <div
        className="gs-item grid-wide set-bg"
        data-setbg="assets/img/gallery/gallery-7.jpg"
        style={{backgroundImage:"url(assets/img/gallery/gallery-7.jpg)"}}
      >
        <a href="assets/img/gallery/gallery-7.jpg" className="thumb-icon image-popup">
          <i className="fa fa-picture-o" />
        </a>
      </div>
      <div className="gs-item set-bg" data-setbg="assets/img/gallery/gallery-8.jpg"   style={{backgroundImage:"url(assets/img/gallery/gallery-8.jpg)"}}>
        <a href="assets/img/gallery/gallery-8.jpg" className="thumb-icon image-popup">
          <i className="fa fa-picture-o" />
        </a>
      </div>
      <div className="gs-item set-bg" data-setbg="assets/img/gallery/gallery-9.jpg"   style={{backgroundImage:"url(assets/img/gallery/gallery-9.jpg)"}}>
        <a href="assets/img/gallery/gallery-9.jpg" className="thumb-icon image-popup">
          <i className="fa fa-picture-o" />
        </a>
      </div>
    </div>
  </div>
  {/* Gallery Section End */}
  {/* Get In Touch Section Begin */}
  <div className="gettouch-section">
    <div className="container">
      <div className="row">
        <div className="col-md-4">
          <div className="gt-text">
            <i className="fa fa-map-marker" />
            <p>
            Dasuya ,Distt: Hoshiarpur
            </p>
          </div>
        </div>
        <div className="col-md-4">
          <div className="gt-text">
            <i className="fa fa-mobile" />
            <ul>
            <li>81468XXXXX</li>
            <li>98779XXXXX</li>
            </ul>
          </div>
        </div>
        <div className="col-md-4">
          <div className="gt-text email">
            <i className="fa fa-envelope" />
            <p>kaurkiranjot47@gmail</p>
          </div>
        </div>
      </div>
    </div>
  </div>
  {/* Get In Touch Section End */}

  {/* Search model Begin */}
  <div className="search-model">
    <div className="h-100 d-flex align-items-center justify-content-center">
      <div className="search-close-switch">+</div>
      <form className="search-model-form">
        <input type="text" id="search-input" placeholder="Search here....." />
      </form>
    </div>
  </div>
  {/* Search model end */}
  {/* Js Plugins */}
</>

    )
}