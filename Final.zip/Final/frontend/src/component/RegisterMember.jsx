import { Link } from "react-router-dom";
import ApiServices from "./layout/ApiServices";
import { useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { ClipLoader } from "react-spinners";
import { useNavigate } from "react-router-dom";
export default function RegisterMember() {

    const nav = useNavigate()

    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [contact, setContact] = useState("");
    const [gender, setGender] = useState("");
    const [address, setAddress] = useState("");
    const [profile, setProfile] = useState("");

    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);
    const [message, setMessage] = useState("");

    const handleSubmit = (e) => {
        e.preventDefault();
        setError("");
        setMessage("");

        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&]).{8,}$/;

        if (!emailPattern.test(email)) {
            setError("Invalid Email Format");
            return;
        }

        if (!passwordPattern.test(password)) {
            setError("Password must contain Uppercase, Lowercase, Number, Special character & Min 8 characters");
            return;
        }

        if (!profile) {
            setError("Profile Image is required");
            return;
        }

        setLoading(true);

        const formData = new FormData();
        formData.append("name", name);
        formData.append("email", email);
        formData.append("password", password);
        formData.append("contact", contact);
        formData.append("gender", gender);
        formData.append("address", address);
        formData.append("profile", profile);

        ApiServices.RegisterCustomer(formData)
            .then((res) => {
                setLoading(false);
                toast.success("Registration Successful!");
                setMessage(res.data.message);  // backend response message
                setName("");
                setEmail("");
                setPassword("");
                setContact("");
                setGender("");
                setAddress("");
                setProfile("");
                setTimeout(() => { nav("/") }, 2000)
            })
            .catch((err) => {
                setLoading(false);
                toast.error("Registration Failed!");
                console.log(err);
            });
    }

    return (
        <>
            <ToastContainer />

            <section className="breadcrumb-section set-bg"
                data-setbg="assets/img/breadcrumb-bg.jpg"
                style={{ backgroundImage: "url(assets/img/breadcrumb-bg.jpg)" }}>
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12 text-center">
                            <div className="breadcrumb-text">
                                <h2>JOIN OUR FAMILY</h2>
                                <div className="bt-option">
                                    <Link to="/">Home</Link>
                                    <span >Register As Member</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <div className="container-fluid">
                <div className="row justify-content-center">
                    <div className="loginbox mx-auto d-block col-lg-4 mt-5 mb-5" >
                        <div className="loginform p-4"  >
                            <h2 className="text-center mb-4" style={{ marginLeft: "5rem" }}>
                                Register As Member
                            </h2>

                            {loading ? (
                                <div className="text-center mb-3">
                                    <ClipLoader color="#000" size={50} />
                                </div>
                            ) : message ? (
                                <div className="alert alert-success text-center w-100" style={{marginLeft:"7rem"}} >
                                    {message}
                                </div>
                            ) : (
                                <form onSubmit={handleSubmit}>
                                    <div className="form">
                                        <input type="text" placeholder="Enter Name" value={name} onChange={(e) => setName(e.target.value)} required />
                                        <input type="email" placeholder="Enter Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                                        <input type="password" placeholder="Enter Password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                                        <input type="text" placeholder="Enter Contact" value={contact} onChange={(e) => setContact(e.target.value)} required />
                                        <input type="text" placeholder="Enter Address" value={address} onChange={(e) => setAddress(e.target.value)} required />

                                        <div className="mb-3 p-3 border rounded bg-light" style={{ marginLeft: "1.3rem" }}>
                                            <div className="form-check">
                                                <input className="form-check-input" type="radio" name="gender" value="Male" checked={gender === "Male"} onChange={(e) => setGender(e.target.value)} />
                                                <label className="form-check-label">Male</label>
                                            </div>
                                            <div className="form-check">
                                                <input className="form-check-input" type="radio" name="gender" value="Female" checked={gender === "Female"} onChange={(e) => setGender(e.target.value)} />
                                                <label className="form-check-label">Female</label>
                                            </div>
                                        </div>

                                        <label htmlFor="profileUpload" className="btn btn-dark w-100" style={{ cursor: "pointer", marginLeft: "1.3rem" }}>
                                            Upload Profile Image
                                        </label>
                                        <input type="file" className="bg-light mb-3" onChange={(e) => setProfile(e.target.files[0])} id="profileUpload" />

                                        {error && <div className="text-danger mb-2">{error}</div>}

                                        <button type="submit" className="btn btn-dark w-100">Register</button>
                                    </div>
                                </form>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
