import { Link, useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import ApiServices from "../layout/ApiServices";
import { toast, ToastContainer } from "react-toastify";
import { ClipLoader } from "react-spinners";
import { useState } from "react";
const ChangePassword = () => {
    const [status, setStatus] = useState(false);
    const [message, setMessage] = useState("");
    const nav = useNavigate()
    const {
        register,
        handleSubmit,
        formState: { errors },
    } = useForm();

    const onSubmit = (data) => {
        if (data.newPassword !== data.confirmPassword) {
            alert("New Password & Confirm Password do not match.");
            return;
        }

        let dataSub = {
            _id: sessionStorage.getItem("_id"),
            currentPassword: data.currentPassword,
            newPassword: data.newPassword,
            confirmPassword: data.newPassword
        }
        console.log(dataSub)
        ApiServices.ChangePassword(dataSub)
            .then((res) => {
                if(res.data.success){
                    
                    toast.success(res.data.message)
                    if(res.data.data.userType == 1){
                        setTimeout(()=>{
                            nav("/admin/manageprofile")
                            toast.dismiss()
                        },3000)
                    }
                    if(res.data.data.userType == 2){
                        setTimeout(()=>{
                            nav("/trainer")
                            toast.dismiss()
                        },3000)    
                    }
                }
                else{
                    toast.error(res.data.message)

                }
                // setMessage(res.data.data.message);
                // toast.success("password changed sucessfully")
            })
            .catch((err) => {
                console.log(err);
                toast.error("an error occured")
            });
    };

    return (
        <>
            <ToastContainer/>
            <section
                className="breadcrumb-section set-bg"
                style={{ backgroundImage: "url(/assets/img/breadcrumb-bg.jpg)" }}
            >
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12 text-center">
                            <div className="breadcrumb-text">
                                <h2>Change Password</h2>
                                <div className="bt-option">
                                    <Link to="/">Home</Link>
                                    <span>Change Password</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <div className="container mt-5">
                <div className="row justify-content-center">
                    <div className="col-md-6 mb-5">
                        <div className="card shadow">
                            <div className="card-body">
                                <h4 className="text-center mb-4">Change Password</h4>
                                <form onSubmit={handleSubmit(onSubmit)}>
                                    <div className="mb-3">
                                        <label for="cpass">Current Password</label>
                                        <input
                                            id="cpass"
                                            type="password"
                                            className="form-control"
                                            {...register("currentPassword", { required: "Current password is required" })}
                                        />
                                        {errors.currentPassword && (
                                            <small className="text-danger">{errors.currentPassword.message}</small>
                                        )}
                                    </div>

                                    <div className="mb-3">
                                        <label for="npass">New Password</label>
                                        <input
                                            id="npass"
                                            type="password"
                                            className="form-control"
                                            {...register("newPassword", { required: "New password is required" })}
                                        />
                                        {errors.newPassword && (
                                            <small className="text-danger">{errors.newPassword.message}</small>
                                        )}
                                    </div>

                                    <div className="mb-3">
                                        <label for="cnpass">Confirm New Password</label>
                                        <input
                                            id="cnpass"
                                            type="password"
                                            className="form-control"
                                            {...register("confirmPassword", { required: "Confirm password is required" })}
                                        />
                                        {errors.confirmPassword && (
                                            <small className="text-danger">{errors.confirmPassword.message}</small>
                                        )}
                                    </div>

                                    <div className="text-center">
                                        <button type="submit" className="btn btn-danger">
                                            Change Password
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default ChangePassword;
