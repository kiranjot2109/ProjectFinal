import React, { useEffect, useState } from 'react'
import { Link, useNavigate } from "react-router-dom"

import { toast } from 'react-toastify';
import { ClipLoader } from "react-spinners"
import ApiServices from '../layout/ApiServices';





const override = {

  margin: "0 auto",
  marginTop: "250px",
  marginBottom: '200px',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  overflow: "hidden"
};

export default function MyBookings() {

  const nav = useNavigate()  //hook must be called outside function
  const [x, setX] = useState(false)
  const [data, setData] = useState([])
  let [color, setColor] = useState("#2c4964;");
  const [isLoading, setIsLoading] = useState(true);
  const [modalShow, setModalShow] = useState(false);

  useEffect(() => {
    var userType = sessionStorage.getItem("userType")
    if (userType != 3) {
      toast.error("Please Login first!!")
      nav("/login")
    }

    let data = {
      customerId: sessionStorage.getItem('customerId')
    }
    ApiServices.BookingAll(data).then((res) => {
      console.log("Result is", res)
      // console.log(res.data.data)
      setData(res.data.data)
      // setSpecialist(res.data.data)
    })
      .catch((err) => { console.log(err) })
    setTimeout(() => {
      setIsLoading(false);
    }, 1500);
  }, [x])

  const storedToken = sessionStorage.getItem("token");
  if (!storedToken) {
    toast.error("user not authenticated! Login first");


  }
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    // Example format: "MM/DD/YYYY"
    const formattedDate = `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`;
    return formattedDate;
  };

  const handlePayment = (booking) => {


    ApiServices.BookingPay({ _id: booking._id }).then((res) => {
      if (res.data.success) {
        const order = res.data.order;
        var options = {
          key: "rzp_test_Llb4dHXmcfxD0L",
          amount: order.amount,
          currency: "INR",
          name: "Acme Corp",
          description: "Test Transaction",
          image: "https://example.com/your_logo",
          order_id: order.id,
          handler: function (response) {
            toast.success(res.data.message);
            setX(true) 
        
          },
          prefill: {
            name: "Kiran",
            email: "kiran@gmail.com",
            contact: "1234567890"
          },
          theme: {
            color: "#3399cc"
          }
        };
        var rzp1 = new window.Razorpay(options);
        rzp1.on('payment.failed', function (response) {
          setIsLoading(false);
          alert(response.error.description);
        });
        rzp1.open();
       


      }


    }).catch((err) => {
        toast.error("Something went wrong!!!")
    })



  }

  return (
    <>
      {/* Breadcrumb Section Begin */}
      <section
        className="breadcrumb-section set-bg"
        data-setbg="/assets/img/breadcrumb-bg.jpg"
        style={{ backgroundImage: "url(assets/img/breadcrumb-bg.jpg)" }}

      >
        <div className="container">
          <div className="row">
            <div className="col-lg-12 text-center">
              <div className="breadcrumb-text">
                <h2>My Bookings</h2>
                <div className="bt-option">
                  <Link to="/">Home</Link>
                  <span>My Bookings</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* Breadcrumb Section End */}
      {isLoading && (
        <ClipLoader
          color={color}
          loading={isLoading}
          cssOverride={override}
          size={100}
          aria-label="Loading Spinner"
          data-testid="loader"
        />
      )}
      {!isLoading && (
        <>
          <section className="contact_section layout_padding">
            <div className="container">
              <div className="heading_container">
                <h2>
                  <span>All Bookings</span>
                </h2>
              </div>
              <div className='table-responsive'>
                <table className=" table table-hover table-striped table mt-5">
                  <thead className="table-dark">
                    <tr>
                      <th>Sr.No</th>
                      <th>Package Name</th>
                      <th>Price</th>
                      <th>Duration</th>
                      <th>Booking Date</th>
                      <th>Status</th>
                      <th>Payment</th>
                    </tr>
                  </thead>
                  <tbody >
                    {data?.map(
                      (el, index) => (
                        <tr >
                          <td>{index + 1}</td>
                          <td>{el?.packageId.name}</td>
                          <td>{el?.packageId.price}</td>
                          <td>{el?.packageId.duration}</td>
                          <td>{formatDate(el?.bookingDate)}</td>
                          <td>  {el.status === 1 ? (
                            <span style={{ backgroundColor: '#5BBCFF' }} class="badge badge-pill badge-info" >Pending</span>
                          ) : el.status === 2 ? (
                            <span style={{ backgroundColor: 'yellow' }} class="badge badge-pill badge-info">Approved</span>
                          ) : el.status === 3 ? (
                            <span style={{ backgroundColor: 'red' }} class="badge badge-pill badge-info">Declined</span>
                          ) : el.status === 4 ? (
                            <span style={{ backgroundColor: 'grey' }} class="badge badge-pill badge-info">Canceled</span>
                          ) : el.status === 5 ? (
                            <span style={{ backgroundColor: 'green' }} class="badge badge-pill badge-info">Completed</span>
                          ) : (
                            <span>{el.status}</span>
                          )}</td>
                          <td>
                            <td>
                              {el?.paymentStatus == 2? (
                                <span className="badge badge-success">Paid</span>
                              ) : (
                                <button onClick={() => handlePayment(el)} className="btn btn-sm btn-primary">Pay Now</button>
                              )}
                            </td>

                          </td>

                        </tr>
                      ))}
                  </tbody>
                </table></div>
            </div>
          </section>

        </>
      )}
    </>

  )
}