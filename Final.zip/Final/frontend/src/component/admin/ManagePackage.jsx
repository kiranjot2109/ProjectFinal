import { Link, useNavigate } from "react-router-dom";
import ApiServices from "../layout/ApiServices";
import { useState, useEffect } from "react";
import { toast, ToastContainer } from "react-toastify";
import ClipLoader from "react-spinners/ClipLoader";
import "react-toastify/dist/ReactToastify.css";
const override= {

  margin: "0 auto",
  marginTop: "250px",
  marginBottom: '200px',
  display:'flex',
  justifyContent: 'center',
  alignItems: 'center',
  overflow:"hidden"
};
export default function ManagePackage() {
    const nav=useNavigate()  //hook must be called outside function
    const [x,setX]=useState(false)
    const [data,setData]=useState([])
    let [color, setColor] = useState("#2c4964;");
    const [isLoading, setIsLoading] = useState(true);


    useEffect(()=>{
        ApiServices.GetAllPackages().then((res)=>{
          console.log("Result is",res)
          // console.log(res.data.data)
          setData(res.data.data)
          // setSpecialist(res.data.data)
      })
        .catch((err)=>{console.log(err)})
        setTimeout(() => {
          setIsLoading(false);
        }, 1500);
      },[x])

      const changeStatus=(id,status)=>{
        
        let data = {
            _id:id,
            status:status
        }
        ApiServices.ChangeStatusPackage(data)
        .then((res)=>{
            console.log("res is",res);
            if(res.data.success){
                toast.success(res.data.message)
                setX(true)
            }
            else{
                toast.error(res.data.message)
                setX(true)
            }
          
            // window.location.reload()
        })
        setX(false)
    }
  return (
    <>
      <ToastContainer position="top-right" autoClose={2000} />

      <section
        className="breadcrumb-section set-bg"
        style={{ backgroundImage: "url(/assets/img/breadcrumb-bg.jpg)" }}
      >
        <div className="container">
          <div className="row">
            <div className="col-lg-12 text-center">
              <div className="breadcrumb-text">
                <h2>Manage Package</h2>
                <div className="bt-option">
                  <Link to="/">Home</Link>
                  <span>Manage Package</span>
                </div>
              </div>
            </div>
          </div> 
        </div>
      </section>
      <>
        {isLoading &&(
            <ClipLoader
            color={color}
            loading={isLoading}
            cssOverride={override}
            size={100}
            aria-label="Loading Spinner"
            data-testid="loader"
          />
          )}
          {!isLoading &&(
        <>
        <section className="contact_section layout_padding">
        <div className="container">
          <div className="heading_container">
            <h2 className="">
              <span>Packages</span>
            </h2>
            {/* <Link className="nav-link col-1" to="/admin/addtrainer">
                <button type="button" class="btn btn-primary btn-lg mx-5">Add</button>
            </Link> */}
          </div>
          <div className='table-responsive'>
          <table className=" table table-hover table-striped table mt-5">
            <thead className="table-dark">
                <tr>
                    <th>Sr.No</th>
                    <th>Name</th>
                    <th>Duration</th>
                    <th>Price</th>
                    <th>Features</th>
                    <th>Status</th>
                    <th>Add</th>
                    <th>Manage</th>
                </tr>
            </thead>
            <tbody >
            {data?.map(
                (el,index)=>(
                <tr >
                    <td>{index+1}</td>
                    <td>{el?.name}</td>
                    <td>{el?.duration}</td>
                    <td>{el?.price}</td>
                    <td>{el?.features}</td>
                    <td>{el.status?"true":"false"}</td>
                    <td> <Link to={"/admin/editPackage/"+el._id} className="text-light btn btn-success">
                   Edit
                      
                    </Link> </td>
                     <td> <>
                      {el.status === true && (
                       
                        <button className="btn text-center text-light" style={{backgroundColor:"crimson",marginLeft:'20px'}} onClick={()=>{changeStatus(el?._id,false)}}>Delete</button>
                        )}

                       {el.status === false && (
                        <button className="btn text-center text-light" style={{backgroundColor:"rgba(41, 171, 135)",marginLeft:'20px'}} onClick={()=>{changeStatus(el?._id,true)}}>Enable</button>
                        )}
                          </>
                    </td>
                </tr>
                ))}
            </tbody>
        </table>
        </div>
        </div>
        </section>
       
          </>
        )} 
        </>
    </>
  );
}
