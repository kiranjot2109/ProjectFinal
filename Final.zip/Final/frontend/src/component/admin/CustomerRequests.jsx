import { Link, useNavigate } from "react-router-dom";
import ApiServices from "../layout/ApiServices";
import { useState, useEffect } from "react";
import { toast, ToastContainer } from "react-toastify";
import ClipLoader from "react-spinners/ClipLoader";
import "react-toastify/dist/ReactToastify.css";
const override= {

  margin: "0 auto",
  marginTop: "250px",
  marginBottom: '200px',
  display:'flex',
  justifyContent: 'center',
  alignItems: 'center',
  overflow:"hidden"
};
export default function CustomerRequest() {
 
  const nav=useNavigate()  //hook must be called outside function
  const [x,setX]=useState(false)
  const [data,setData]=useState([])
  const [name,setName]=useState("")
  const [image,setImage]=useState({})
  const [imageName,setImageName]=useState("")
  let [color, setColor] = useState("#2c4964;");
  const [isLoading, setIsLoading] = useState(true);
  const [modalShow, setModalShow] = useState(false);

  useEffect(()=>{
      ApiServices.BookingAll().then((res)=>{
        console.log("Result is",res)
        // console.log(res.data.data)
        setData(res.data.data)
        // setSpecialist(res.data.data)
    })
      .catch((err)=>{console.log(err)})
      setTimeout(() => {
        setIsLoading(false);
      }, 1500);
    },[x])

    const changeStatus=(id,status)=>{
      let data = {
          _id:id,
          status:status
      }
      ApiServices.BookingStatus(data)
      .then((res)=>{
          toast.success(res.data.message)
          setX(true)
          // window.location.reload()
      })
      setX(false)
  }
  const formatDate = (dateString) => {
      const date = new Date(dateString);
      // Example format: "MM/DD/YYYY"
      const formattedDate = `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`;
      return formattedDate;
  };
  return (
    <>
      <ToastContainer position="top-right" autoClose={2000} />

      <section
        className="breadcrumb-section set-bg"
        style={{ backgroundImage: "url(/assets/img/breadcrumb-bg.jpg)" }}
      >
        <div className="container">
          <div className="row">
            <div className="col-lg-12 text-center">
              <div className="breadcrumb-text">
                <h2>Manage Requests</h2>
                <div className="bt-option">
                  <Link to="/">Home</Link>
                  <span>Manage Requests</span>
                </div>
              </div>
            </div>
          </div> 
        </div>
      </section>
      <>
        {isLoading &&(
            <ClipLoader
            color={color}
            loading={isLoading}
            cssOverride={override}
            size={100}
            aria-label="Loading Spinner"
            data-testid="loader"
          />
          )}
          {!isLoading &&(
        <>
        <section className="contact_section layout_padding">
        <div className="container">
          <div className="heading_container">

            {/* <Link className="nav-link col-1" to="/admin/addtrainer">
                <button type="button" class="btn btn-primary btn-lg mx-5">Add</button>
            </Link> */}
          </div>
          <div className='table-responsive'>
          <table className=" table table-hover table-striped table mt-5">
            <thead className="table-dark">
                <tr>
                    <th>Sr.No</th>
                    <th>Customer Name</th>
                    <th>Profile</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Package Name</th>
                    <th>Duration</th>
                    <th>Booking Date</th>
                    <th className='text-center'>Action</th>
                    <th>Assign Trainer</th>
                     
                </tr>
            </thead>
            <tbody >
            {data?.filter(el=>el.status!==4).map(
                (el,index)=>(
                <tr >
                    <td>{index+1}</td>
                    <td>{el.customerId?.name}</td>
                    <td>
                            <img src={BASE_URL+el.customerId?.profile} style={{height:"100px",width:"100px"}}/>
                    </td>
                    <td>{el.customerId?.email}</td>
                    <td>{el.customerId?.address}</td>
                    <td>{el.packageId?.name}</td>
                    <td>{el.packageId?.duration}</td>
                    <td>{formatDate(el?.bookingDate)}</td>
                    <td> 
                      <div style={{display:'flex' , gap:'20px'}}>
                      {el.status === 2 && (
                       
                        <button className="btn text-center text-light" style={{backgroundColor:"crimson"}} onClick={()=>{changeStatus(el?._id,4)}}>Delete</button>
                        )}
                        {el.status === 2 && (
                       
                       <button className="btn text-center text-light" style={{backgroundColor:"rgba(41, 171, 135)"}} onClick={()=>{changeStatus(el?._id,5)}}>Complete</button>
                       )}

                       {el.status === 4 && (
                         <h6>Deleted</h6>
                       )}
                       {el.status === 5 && (
                         <h6>Completed</h6>
                       )}
                       {el.status === 1 && (
                        <button className="btn text-center text-light" style={{backgroundColor:"rgba(41, 171, 135)", width:'70%'}} onClick={()=>{changeStatus(el?._id,2)}}>Approve</button>
                        )}
                    
                       {el.status === 1 && (
                        <button className="btn text-center text-light" style={{backgroundColor:"crimson",width:'70%'}} onClick={()=>{changeStatus(el?._id,3)}}>Decline</button>
                        )}
                        
                        </div>
                        </td>
                        <td>
                        {el.status === 2 && (
                       
                       <Link to={"/admin/assignTrainers/"+el._id}>
                       <button className="btn text-center text-light" style={{backgroundColor:"rgba(41, 171, 135)"}} >Assign Trainer</button>
                      </Link> 
                       )}

                       {(el.status === 1 || el.status === 3 || el.status === 4 || el.status === 5) && (
                       <button className="btn text-center text-light" style={{backgroundColor:"grey"}} disabled>Assign Trainer</button>             
                       )}
                       
                        </td>
                </tr>
                ))}
            </tbody>
        </table>
        </div>
        </div>
        </section>
       
          </>
        )} 
        </>
    </>
  );
}
