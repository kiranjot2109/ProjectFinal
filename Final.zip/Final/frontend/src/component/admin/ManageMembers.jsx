import { Link, useNavigate } from "react-router-dom";
import ApiServices from "../layout/ApiServices";
import { useState, useEffect } from "react";
import { toast, ToastContainer } from "react-toastify";
import ClipLoader from "react-spinners/ClipLoader";
import "react-toastify/dist/ReactToastify.css";
const override= {

    margin: "0 auto",
    marginTop: "250px",
    marginBottom: '200px',
    display:'flex',
    justifyContent: 'center',
    alignItems: 'center',
    overflow:"hidden"
  };

export default function ManageMembers() {
    const [x,setX]=useState(false)
    let [color, setColor] = useState("#2c4964;");
    const [isLoading, setIsLoading] = useState(true);
    const [data,setData]=useState([])
  

    useEffect(()=>{
  
        ApiServices.AllCustomer()
        .then((res)=>{
          // console.log(data);
          setData(res.data.data)
          console.log("data",res.data.data);
     
        })
        .catch((err)=>{
            console.log(err);
        })
        setTimeout(() => {
          setIsLoading(false);
        }, 1500);
        
      },[x])

      const changeStatus=(id,status)=>{
        let data = {
            _id:id,
            status:status
        }
        ApiServices.changeStatusCustomer(data)
        .then((res)=>{
            toast.success(res.data.message)
            setX(true)
            // window.location.reload()
        })
        .catch((error)=>{
            toast.error(error.data.message)
        })
        setX(false)
    }

  return (
    <>
      <ToastContainer position="top-right" autoClose={2000} />

      <section
        className="breadcrumb-section set-bg"
        style={{ backgroundImage: "url(/assets/img/breadcrumb-bg.jpg)" }}
      >
        <div className="container">
          <div className="row">
            <div className="col-lg-12 text-center">
              <div className="breadcrumb-text">
                <h2>Manage Members</h2>
                <div className="bt-option">
                  <Link to="/">Home</Link>
                  <span>Manage Members</span>
                </div>
              </div>
            </div>
          </div> 
        </div>
      </section>
      <>
        {isLoading &&(
            <ClipLoader
            color={color}
            loading={isLoading}
            cssOverride={override}
            size={100}
            aria-label="Loading Spinner"
            data-testid="loader"
          />
          )}
          {!isLoading &&(
        <>
        <section className="contact_section layout_padding">
        <div className="container">
          <div className="heading_container">

            {/* <Link className="nav-link col-1" to="/admin/addtrainer">
                <button type="button" class="btn btn-primary btn-lg mx-5">Add</button>
            </Link> */}
          </div>
          <div className='table-responsive'>
          <table className=" table table-hover table-striped table mt-5">
            <thead className="table-dark">
                <tr>
                    <th>Sr.No</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Gender</th>
                    <th>Contact</th>
                    <th>Address</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody >
            {data?.map(
                (el,index)=>(
                <tr key={index}>
                    <td>{index+1}</td>
                    <td>{el?.name}</td>
                    <td>{el?.email}</td>
                    <td>{el?.gender}</td>
                    <td>{el?.contact}</td>
                    <td>{el?.address}</td>
                    <td>{el?.status==true?"Approved":el?.status==false?"Pending/Declined":el?.status}</td>
                    <td> 
                      <>
                      {el.status === true && (
                       
                        <button className="btn text-center text-light" style={{backgroundColor:"crimson"}} onClick={()=>{changeStatus(el?._id,false)}}>Disable</button>
                        )}

                       {el.status === false && (
                        <button className="btn text-center text-light" style={{backgroundColor:"rgba(41, 171, 135)"}} onClick={()=>{changeStatus(el?._id,true)}}>Approve</button>
                        )}
                          </>
                    </td>
                </tr>
                ))}
            </tbody>
        </table>
        </div>
        </div>
        </section>
       
          </>
        )} 
        </>
    </>
  );
}
