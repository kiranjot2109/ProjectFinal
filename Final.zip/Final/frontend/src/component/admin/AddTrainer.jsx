import { Link, useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";

import { toast, ToastContainer } from "react-toastify";
import { ClipLoader } from "react-spinners";
import { useState } from "react";
import ApiServices from "../layout/ApiServices";
function AddTrainer() {
    var [load, setload] = useState(false)
    var [name, setName] = useState("")
    var [email, setemail] = useState("")
    var [password, setpassword] = useState("")
    var [contact, setcontact] = useState("")
    var [address, setaddress] = useState("")
    var [experience, setexperience] = useState("")
    var [Image, setImage] = useState("")
    const nav = useNavigate()
    const handleSubmit = (e) => {
        e.preventDefault();

        if(!name || !email || !password || !contact || !address || !experience || !Image) {
            toast.error("Please fill all fields!!");
            return;
        }
        setload(true); // 👈 Start loader
        let data = new FormData();
        data.append("name", name);
        data.append("email", email);
        data.append("password", password);
        data.append("contact", contact);
        data.append("address", address);
        data.append("experience", experience);
        data.append("profile", Image);

        ApiServices.AddTrainer(data)
            .then((res) => {
                setload(false); // 👈 Stop loader here

                if (res.data.success) {
                    toast.success(res.data.message);
                    setemail("");
                    setName("");
                    setpassword("");
                    setcontact("");
                    setaddress("");
                    setexperience("");
                    setImage("");

                    setTimeout(() => {
                        nav("/admin/AddTrainer");
                    }, 1500); // Give time for toast to show
                } else {
                    toast.error(res.data.message);
                }
            })
            .catch((err) => {
                setload(false); // 👈 Stop loader on error
                toast.error("Internal server error!!");
            });
    };



    return (
        <>
            <ToastContainer />
            <section
                className="breadcrumb-section set-bg"
                style={{ backgroundImage: "url(/assets/img/breadcrumb-bg.jpg)" }}
            >
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12 text-center">
                            <div className="breadcrumb-text">
                                <h2>Add Trainer</h2>
                                <div className="bt-option">
                                    <Link to="/">Home</Link>
                                    <span>Add Trainer</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <div className="container mt-5">
                <div className="row justify-content-center">
                    <div className="col-md-10 mb-5">

                        <h4 className="text-center mb-4">Add Trainer</h4>
                        <ClipLoader loading={load} style={{ marginLeft: "40%" }} />
                        {
                            !load ?
                                <div className="loginbox mx-auto d-block col-lg-8 mt-5 mb-5">
                                    <div className="loginform p-4">
                                        <h2 className="text-center mb-4" style={{ marginLeft: "20px" }}>
                                            Add Trainer
                                        </h2>
                                        <form onSubmit={handleSubmit}>
                                            <div className="form">
                                                <label className="text-white form-label " style={{ marginLeft: "20px" }}>Name</label>
                                                <input className="w-100" type="text" placeholder="Enter Name" value={name}
                                                    onChange={(e) => { setName(e.target.value) }} required />
                                                <label className="text-white form-label " style={{ marginLeft: "20px" }}>Email</label>
                                                <input type="email" className="w-100" placeholder="Enter Email" value={email} onChange={(e) => { setemail(e.target.value) }} required />
                                                <label className="text-white form-label " style={{ marginLeft: "20px" }}>Address</label>
                                                <textarea
                                                    id="npass"

                                                    className="form-control w-100 "
                                                    style={{marginLeft:"20px"}}
                                                    value={address}
                                                    onChange={(e) => { setaddress(e.target.value) }}
                                                    required
                                                ></textarea>
                                                <label className="text-white form-label " style={{ marginLeft: "20px" }}>Password</label>
                                                <input type="password" className="w-100" value={password}
                                                    onChange={(e) => { setpassword(e.target.value) }} required />
                                                <label className="text-white form-label " style={{ marginLeft: "20px" }}>Contact</label>
                                                <input type="number" className="w-100" value={contact}
                                                    pattern="[0-9]{10}"
                                                    onChange={(e) => { setcontact(e.target.value) }} required />
                                                <label className="text-white form-label " style={{ marginLeft: "20px" }}>Experience</label>
                                                <input type="text" className="w-100" value={experience}
                                                    onChange={(e) => { setexperience(e.target.value) }} required />
                                                <label className="text-white form-label " style={{ marginLeft: "20px" }}>Image</label>
                                                <input type="file" className="w-100"
                                                    onChange={(e) => { setImage(e.target.files[0]) }} required />
                                                <button type="submit" className="btn btn-danger text-light mt-3" style={{ marginLeft: "20px" }}>
                                                    {load ? <ClipLoader size={20} color="#fff" /> : "Add"}
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div> : ""
                        }

                    </div>
                </div>

            </div>
        </>
    );
};

export default AddTrainer;
