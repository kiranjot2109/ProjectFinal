// visitor interface components
import Home from './component/Home'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import CustomerMaster from './component/layout/CustomerPanel/Master'
import AboutUs from './component/AboutUs'
import Classes from './component/Classes'
import Services from './component/Services'
import OurTeam from './component/OurTeam'
import ClassTimetable from './component/ClassTimetable'
import Gallery from './component/Gallery'
import Blog from './component/Blog'
import Error from './component/Error'
import Contact from './component/Contact'
import Admin from './component/Admin'
import Login from './component/Login'
import Trainer from './component/Trainer'
import VisitorMaster from './component/layout/VisitorPanel/VisitorMaster'
import Register from './component/Register'
import RegisterTrainer from './component/RegisterTrainer'
import RegisterMember from './component/RegisterMember'
//admin
import AdminMaster from './component/layout/AdminPanel/AdminMaster'
import TrainerRequest from './component/admin/TrainerRequest'
import ChangePassword from './component/admin/ChangePassword'
import ViewDailyEntries from './component/admin/ViewDailyEntries'
import ViewQueries from './component/admin/ViewQueries'
import ManageProfile from './component/admin/ManageProfile'
//trainer
import TrainerMaster from './component/layout/TrainerPanel/TrainerMaster'
import ViewRequest from './component/trainer/viewRequest'
import DailyEntry from './component/trainer/DailyEntry'
import Query from './component/trainer/Query'
import ManageWorkout from './component/trainer/ManageWorkout'
import AddDietPlans from './component/trainer/AddDietPlans'
import WorkoutPlans from './component/trainer/WorkoutPlans'
//customer
import ViewDailyEntry from './component/customer/ViewDailyEntry'
import CManageProfile from './component/customer/CManageProfile'
import SendRequest from './component/customer/SendRequest'
import UploadQuery from './component/customer/UploadQuery'
import ViewDietPlans from './component/customer/ViewDietPlans'
import ViewWorkouts from './component/customer/ViewWorkouts'
import BmiCalculate from './component/customer/BmiCalculate'
import CustomerRequests from './component/admin/CustomerRequests'
import AddTrainer from './component/admin/AddTrainer'
import Requests from './component/admin/Requests'
import AddPackage from './component/admin/AddPackage'
import ManagePackage from './component/admin/ManagePackage'
import UpdatePackage from './component/admin/UpdatePackage'
import ManageTrainers from './component/layout/AdminPanel/ManageTrainers'
import ManageMembers from './component/admin/ManageMembers'
import AllReports from './component/admin/AllReports'
import ViewMembers from './component/trainer/ViewMembers'
import AddSession from './component/trainer/AddSession'
import ManageSession from './component/trainer/ManageSession'
import UpdateSession from './component/trainer/UpdateSession'
import BuyPackage from './component/buyPackage'
import MyBookings from './component/admin/MyBookings'
import ViewMySession from './component/customer/ViewMySession'
import AssignTrainer from './component/admin/AssignTrainer'
import ViewSession from './component/trainer/ViewSession'
import AddReport from './component/trainer/AddReport'
import SingleSession from './component/customer/SingleSession'
import UpdateTrainer from './component/layout/AdminPanel/UpdateTrainer'


function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<VisitorMaster/>}>
            <Route path='/' element={<Home />} />
            <Route path='/about-us' element={<AboutUs />} />
            <Route path='/classes' element={<Classes />} />
            <Route path='/services' element={<Services />} />
            <Route path='/packages' element={<BuyPackage />} />
            <Route path='/mybookings' element={<MyBookings />} />
          <Route path="/Sessions" element={<ViewMySession/>}/>
          <Route path="/SingleSession/:id" element={<SingleSession/>}/>

            <Route path='/team' element={<OurTeam />} />
            <Route path='/Gallery' element={<Gallery />} />
            <Route path='/Blog' element={<Blog />} />
            <Route path='/404' element={<Error />} />
            <Route path='/contact' element={<Contact />} />
            <Route path='/login' element={<Login />} />
            <Route path='/register' element={<Register />} />
            <Route path='/register-member' element={<RegisterMember />} />
            <Route path='/register-trainer' element={<RegisterTrainer />} />
          </Route>

        

          <Route path='/admin' element={<AdminMaster />}>
            <Route path='/admin' element={<Admin />} />
            <Route path='/admin/AddPackage' element={<AddPackage />} />
            <Route path='/admin/ManagePackage' element={<ManagePackage />} />
            <Route path='/admin/editPackage/:id' element={<UpdatePackage />} />
            <Route path='/admin/Requests' element={<TrainerRequest />} />
            <Route path='/admin/assignTrainers/:id' element={<AssignTrainer />} />
            <Route path='/admin/AddTrainer' element={<AddTrainer />} />
            <Route path='/admin/ManageTrainer' element={<ManageTrainers />} />
            <Route path='/admin/editTrainers/:_id' element={<UpdateTrainer />} />
            <Route path='/admin/changepass' element={<ChangePassword />} />
          
            <Route path='/admin/dailyEntry' element={<ViewDailyEntries />} />
            {/* <Route path='/admin/requests' element={<Requests />} /> */}
            <Route path='/admin/queries' element={<ViewQueries />} />
            <Route path='/admin/manageprofile' element={<ManageProfile />} />
            <Route path='/admin/customerReq' element={<CustomerRequests />} />
            <Route path='/admin/ManageMembers' element={<ManageMembers />} />
            <Route path='/admin/AllReports' element={<AllReports />} />
          </Route>
          <Route path='/trainer' element={<TrainerMaster />}>
            <Route path='/trainer' element={<Trainer />} />
            <Route path='/trainer/viewReq' element={<ViewRequest />} />
            <Route path="/trainer/addSession/:id" element={<AddSession/>}/>
            <Route path='/trainer/changepass' element={<ChangePassword />} />
            <Route path='/trainer/viewMembers' element={<ViewMembers />} />
            <Route path="/trainer/viewSession/:id" element={<ViewSession/>}/>
            <Route path='/trainer/manageprofile' element={<ManageProfile />} />
            <Route path='/trainer/dailyEntry' element={<DailyEntry />} />
            <Route path='/trainer/allReports' element={<AllReports />} />
            <Route path="/trainer/managesession" element={<ManageSession/>}/>
            <Route path="/trainer/updateSession/:id" element={<UpdateSession/>}/>
            <Route path="/trainer/addReport/:id" element={<AddReport/>}/>
            <Route path='/trainer/dietplan/add' element={<AddDietPlans />} />
            <Route path='/trainer/workoutplan' element={<WorkoutPlans />} />
            <Route path='/trainer/queries' element={<Query />} />
            {/* <Route path='/trainer/manageworkout' element={<ManageWorkout />} /> */}
          </Route>
        </Routes>

      </BrowserRouter>
    </>
  )
}

export default App
