import { Link } from "react-router-dom";
import { useState } from "react";
import ApiServices from "../layout/ApiServices";
export default function AddDietPlans() {
  const initialFormData = {
    trainerId: "",
    customerId: "",
    dietPlanName: "",
    restrictions: "",
    description: "",
    duration: "",
  }
  const [formData, setFormData] = useState(initialFormData);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    ApiServices.addDietPlan(formData)
      .then((res) => {
        console.log(res.data)
      })
      .catch((err) => {

      })
    setFormData(initialFormData)
  };

  return (
    <>
      <section
        className="breadcrumb-section set-bg"
        style={{ backgroundImage: "url(/assets/img/breadcrumb-bg.jpg)" }}
      >
        <div className="container">
          <div className="row">
            <div className="col-lg-12 text-center">
              <div className="breadcrumb-text">
                <h2>Diet Plans</h2>
                <div className="bt-option">
                  <Link to="/">Home</Link>
                  <span>Diet Plan</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Form Section */}
      <section className="contact-form spad">
        <div className="container">
          <h3 className="text-center mb-4">Add New Diet Plan</h3>
          <form onSubmit={handleSubmit} className="row g-3">
            <div className="col-md-6">
              <label className="form-label">Trainer ID</label>
              <input
                type="text"
                className="form-control"
                name="trainerId"
                value={formData.trainerId}
                onChange={handleChange}
                required
              />
            </div>

            <div className="col-md-6">
              <label className="form-label">Customer ID (Optional)</label>
              <input
                type="text"
                className="form-control"
                name="customerId"
                value={formData.customerId}
                onChange={handleChange}
              />
            </div>

            <div className="col-md-6">
              <label className="form-label">Diet Plan Name</label>
              <input
                type="text"
                className="form-control"
                name="dietPlanName"
                value={formData.dietPlanName}
                onChange={handleChange}
                required
              />
            </div>

            <div className="col-md-6">
              <label className="form-label">Restrictions</label>
              <input
                type="text"
                className="form-control"
                name="restrictions"
                value={formData.restrictions}
                onChange={handleChange}
              />
            </div>

            <div className="col-12">
              <label className="form-label">Description (Include Breakfast, Meal, Dinner)</label>
              <textarea
                className="form-control"
                name="description"
                rows="4"
                value={formData.description}
                onChange={handleChange}
                required
              ></textarea>
            </div>

            <div className="col-md-6">
              <label className="form-label">Duration (e.g., 30 days)</label>
              <input
                type="text"
                className="form-control"
                name="duration"
                value={formData.duration}
                onChange={handleChange}
                required
              />
            </div>

            <div className="col-12 text-center mt-3">
              <button type="submit" className="btn btn-primary">
                Submit Plan
              </button>
            </div>
          </form>
        </div>
      </section>
    </>
  );
}
