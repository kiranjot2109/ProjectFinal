import { Link } from "react-router-dom";
export default function WorkoutPlans()
{
    return(
        <>
        <section
    className="breadcrumb-section set-bg"
    // data-setbg="assets/img/breadcrumb-bg.jpg"
    style={{backgroundImage:"url(/assets/img/breadcrumb-bg.jpg)"}}
  >
    <div className="container">
      <div className="row">
        <div className="col-lg-12 text-center">
          <div className="breadcrumb-text">
            <h2> Workout Plans</h2>
            <div className="bt-option">
              <Link to="/">Home</Link>
              {/* <Link to="/admin/trainerReq">TrainerRequest</Link> */}
              <span> Workout plan</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Breadcrumb Section End */}

    {/*Table */}
    <div className ="container mt-4">
    <h3 className="fw-bold">Workout plan</h3><br></br>
    <table className="table table-bordered table-striped">
        <thead className="thead-dark"
        // className="table-light"
        >
            <tr>
                <th>Trainer Name</th>
                <th>Member Name</th>
                <th>Workout detail</th>
                <th>Duration</th>
                {/* <th>Feedback</th>
                <th>Status</th>
                <th>Action
                    <div className="btn-group  ms-2">
                    <button  style={{color:"oranged"}}>Accept</button>
                    <button  style={{color:"oranged"}}>Reject</button>
                    <button c style={{color:"oranged"}}>Block</button>
                    </div>
                </th> */}
            </tr>
            </thead>
            <tbody>
                <tr>
                <td>1.</td>
                <td>abc</td>
                <td>xxx</td>
                <td>xxxxxxxx</td>
               
                </tr>
                <tr>
                <td>2.</td>
                <td>cde</td>
                <td>xyz</td>
                <td>xx</td>
               
                </tr>
                <tr>
                <td>3.</td>
                <td>cde</td>
                <td>xyz</td>
                <td>xx</td>
               
                </tr>
                <tr>
                <td>4.</td>
                <td></td>
                <td></td>
                <td></td>
               
                </tr>
                </tbody> </table>
  </div>
        </>
    )
}