import { Link } from "react-router-dom";

import { useEffect, useState } from "react";
import { ClipLoader } from "react-spinners";
import ApiServices from "../layout/ApiServices";
const override= {

    margin: "0 auto",
    marginTop: "250px",
    marginBottom: '200px',
    display:'flex',
    justifyContent: 'center',
    alignItems: 'center',
    overflow:"hidden"
  };

export default function ViewMembers()
{
    const [x,setX]=useState(false)
    let [color, setColor] = useState("#2c4964;");
    const [isLoading, setIsLoading] = useState(true);
    const [data,setData]=useState([])
  

    useEffect(()=>{

         let trainer= {
            trainerId:sessionStorage.getItem("trainerId")
         }
        ApiServices.TrainerAssignAll(trainer)
        .then((res)=>{
          // console.log(data);
          setData(res.data.data)
          console.log("data",res.data.data);
     
        })
        .catch((err)=>{
            console.log(err);
        })
        setTimeout(() => {
          setIsLoading(false);
        }, 1500);
        
      },[])
    return(
        <>
        <section
    className="breadcrumb-section set-bg"
    // data-setbg="assets/img/breadcrumb-bg.jpg"
    style={{backgroundImage:"url(/assets/img/breadcrumb-bg.jpg)"}}
  >
    <div className="container">
      <div className="row">
        <div className="col-lg-12 text-center">
          <div className="breadcrumb-text">
            <h2>View Members</h2>
            <div className="bt-option">
              <Link to="/">Home</Link>
              {/* <Link to="/admin/trainerReq">TrainerRequest</Link> */}
              <span >View Members</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Breadcrumb Section End */}

  {/*Table */}
  <div className ="container mt-4">
    {/* <h3 className="fw-bold">View Request</h3><br></br> */}
    {isLoading &&(
            <ClipLoader
            color={color}
            loading={isLoading}
            cssOverride={override}
            size={100}
            aria-label="Loading Spinner"
            data-testid="loader"
          />
          )}
          {!isLoading &&(
        <>
        <section className="contact_section layout_padding">
        <div className="container">
          <div className="heading_container">
            <h2 className="">
              <span>Assign Customers</span>
            </h2>
            {/* <Link className="nav-link col-1" to="/admin/addtrainer">
                <button type="button" class="btn btn-primary btn-lg mx-5">Add</button>
            </Link> */}
          </div>
          <div className='table-responsive'>
        <table className=" table table-hover table-striped table mt-5">
            <thead className="table-dark">
                <tr>
                    <th>Sr.No</th>
                    <th>Customer Name</th>
                    <th>Email</th>
                    <th>Gender</th>
                    <th>Package Name</th>
                    <th>Price</th>
                    <th>Duration</th>
                    <th>Add Session</th>
                </tr>
            </thead>
            <tbody >
            {data?.map(
                (el,index)=>(
                <tr key={index}>
                    <td>{index+1}</td>
                    <td>{el.customerId?.name}</td>
                    <td>{el.customerId?.email}</td>
                    <td>{el.customerId?.gender}</td>
                    <td>{el.packageId?.name}</td>
                    <td>{el.packageId?.price}</td>
                    <td>{el.packageId?.duration}</td>
                    <td> 
                         <Link to={"/trainer/addSession/"+el._id}>
                        <button className="btn text-center text-light" style={{backgroundColor:"rgba(41, 171, 135)"}}>Add Session</button>
                         </Link>
                    </td>
                </tr>
                ))}
            </tbody>
        </table>
        </div>
        </div>
        </section>
       
          </>
        )} 
  </div>
        </>
    )
}