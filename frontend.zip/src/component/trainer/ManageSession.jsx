import React, { useEffect, useState } from 'react'
import { useNavigate } from "react-router-dom"

import { toast, ToastContainer } from 'react-toastify';
import {ClipLoader} from "react-spinners"
import { Link } from "react-router-dom";
import ApiServices from '../layout/ApiServices';




const override= {

    margin: "0 auto",
    marginTop: "250px",
    marginBottom: '200px',
    display:'flex',
    justifyContent: 'center',
    alignItems: 'center',
    overflow:"hidden"
  };
export default function ManageSession(){

    const nav=useNavigate()  //hook must be called outside function
    const [x,setX]=useState(false)
    const [data,setData]=useState([])
    let [color, setColor] = useState("#2c4964;");
    const [isLoading, setIsLoading] = useState(true);


    useEffect(()=>{
      let data= {
         trainerId:sessionStorage.getItem("trainerId")
      }
        ApiServices.SessionAll(data).then((res)=>{
          console.log("Result is",res)
          // console.log(res.data.data)
          setData(res.data.data)
          // setSpecialist(res.data.data)
      })
        .catch((err)=>{console.log(err)})
        setTimeout(() => {
          setIsLoading(false);
        }, 1500);
      },[x])

      const changeStatus=(id,status)=>{
        let data = {
            _id:id,
            status:status
        }
        ApiServices.SessionStatus(data)
        .then((res)=>{
            toast.success(res.data.message)
            setX(true)
            // window.location.reload()
        })
        setX(false)
    }
    const storedToken = sessionStorage.getItem("token");
    if(!storedToken){
      toast.error("user not authenticated! Login first");
      
   
    }
    return(
        
        <>
          <ToastContainer position="top-right" autoClose={2000} />

<section
  className="breadcrumb-section set-bg"
  style={{ backgroundImage: "url(/assets/img/breadcrumb-bg.jpg)" }}
>
  <div className="container">
    <div className="row">
      <div className="col-lg-12 text-center">
        <div className="breadcrumb-text">
          <h2>Manage Session</h2>
          <div className="bt-option">
            <Link to="/">Home</Link>
            <span>Manage Session</span>
          </div>
        </div>
      </div>
    </div> 
  </div>
</section>
    {isLoading &&(
        <ClipLoader
        color={color}
        loading={isLoading}
        cssOverride={override}
        size={100}
        aria-label="Loading Spinner"
        data-testid="loader"
      />
      )}
      {!isLoading &&(
        <>
        <section className="contact_section layout_padding">
        <div className="container">
          <div className="heading_container">
            <h2>
              <span>Manage Session</span>
            </h2>
          </div>
          <div className='table-responsive'>
        <table className=" table table-hover table-striped table mt-5">
            <thead className="table-dark">
                <tr>
                    <th>Sr.No</th>
                    <th>Customer Name</th>
                    <th>Contact</th>
                    <th>Address</th>
                    <th>Gender</th>
                    <th>Diet</th>
                    <th>View</th>
                    <th>Action</th>
                    <th>Report</th>
                </tr>
            </thead>
            <tbody >
            {data?.map(
                (el,index)=>(
                <tr >
                    <td>{index+1}</td>
                    <td>{el.customerId?.name}</td>
                    <td>{el.customerId?.contact}</td>
                    <td>{el.customerId?.address}</td>
                    <td>{el.customerId?.gender}</td>
                    <td>{el.diet}</td>

                    <td> <Link to={"/trainer/viewSession/"+el._id}><button className='btn text-light' style={{backgroundColor:"#22A699"}}>
                     View
                      
                    </button></Link></td>
                    <td> 
                      <>
                      {el.status === true && (
                       
                        <button className="btn text-center text-light" style={{backgroundColor:"crimson"}} onClick={()=>{changeStatus(el?._id,false)}}>Disable</button>
                        )}

                       {el.status === false && (
                        <button className="btn text-center text-light" style={{backgroundColor:"rgba(41, 171, 135)"}} onClick={()=>{changeStatus(el?._id,true)}}>Approve</button>
                        )}
                          </>
                    </td>
                    
                    <td> <Link to={"/trainer/addReport/"+el._id}><button className='btn text-light' style={{backgroundColor:"#30A2FF"}}>
                      Add Report
                    </button></Link></td>
                </tr>
                ))}
            </tbody>
        </table></div>
        </div>
        </section>

            </>
        )}
        </>
      
    )
}