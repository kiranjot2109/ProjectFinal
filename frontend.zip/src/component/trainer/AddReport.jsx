import React, { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from "react-router-dom";
import axios from 'axios';
import { toast } from 'react-toastify';
import {ClipLoader} from "react-spinners"
import ApiServices from '../layout/ApiServices';

const override= {

  margin: "0 auto",
  marginTop: "250px",
  marginBottom: '200px',
  display:'flex',
  justifyContent: 'center',
  alignItems: 'center',
  overflow:"hidden"
};

export default function AddReport(){
  const [customerId, setCustomerId] = useState("")
  const [customerName, setCustomerName] = useState("")
  const [trainerId, setTrainerId] = useState("")
  const [sessionScore, setSessionScore] = useState()
  const [dietScore, setDietScore] = useState()
  const [height, setHeight] = useState()
  const [weight, setWeight] = useState()
  const [week, setWeek] = useState()
  // const [x, setX] = useState(false)
  let [color, setColor] = useState("#2c4964;");
const [isLoading, setIsLoading] = useState(true);

const param=useParams()
console.log(param);
const id=param.id 
const nav = useNavigate()
useEffect(()=>{
  let single ={
     _id:id
  }
 ApiServices.SessionSingle(single)
 .then((res)=>{
     console.log(res)
    setCustomerId(res.data.data.customerId._id);
    setCustomerName(res.data.data.customerId.name);
    setTrainerId(res.data.data.trainerId._id);
    setWeek(res.data.data.week);
 }).catch((err)=>{
     console.log(err);
 })
 setTimeout(() => {
  setIsLoading(false);
}, 1500);

},[])

  const Submitted=(e)=>{
    e.preventDefault()
    let obj ={
      Authorization:sessionStorage.getItem("token")
    }
    console.log("obj is:",obj)
    let data={
    customerId:customerId,
    trainerId:trainerId,
    week:week,
    sessionScore:sessionScore,
    dietScore:dietScore,
    height:height,
    weight:weight
    }

    ApiServices.ReportAdd(data).then(
      (res)=>{
        
        if(res.data.success==true){
        console.log(res)
        toast.success(res.data.message);
        setSessionScore("");
        setDietScore("");
        setHeight("");
        setWeight("");
        
        } 
        else{
          toast.error(res.data.message)
        }
      }
     
    ).catch(
      (err)=>{
        console.log(err);
        toast.error(err.data.message)
      }
    )
// setX(false)
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    // Example format: "MM/DD/YYYY"
    const formattedDate = `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`;
    return formattedDate;
};

    return(
      <>
       {/* Breadcrumb Section Begin */}
               <section
                className="breadcrumb-section set-bg"
                data-setbg="/assets/img/breadcrumb-bg.jpg"
          style={{backgroundImage:"url(/assets/img/breadcrumb-bg.jpg)"}}
      
              >
                <div className="container">
                  <div className="row">
                    <div className="col-lg-12 text-center">
                      <div className="breadcrumb-text">
                        <h2>Add Reports</h2>
                        <div className="bt-option">
                          <Link to="/">Home</Link>
                          <span>Add Reports</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
              {/* Breadcrumb Section End */}
       {/* Breadcrumb Section Begin */}
              
              {/* Breadcrumb Section End */}
      {isLoading ? (
                <ClipLoader
                color={color}
                loading={isLoading}
                cssOverride={override}
                size={100}
                aria-label="Loading Spinner"
                data-testid="loader"
              />
      ) : (
        <section className="contact_section layout_padding">
          <div className="container" >

          <div style={{float:'right'}}>
              <Link className="nav-link" to="/trainer/allReports">
                <button type="button" className="btn btn-danger mx-5">Manage Reports</button>
              </Link>
            </div>
            <div className="heading_container" style={{marginLeft:'200px'}}>
              <h2><span>Add Report</span></h2>
       
            </div>
            <div className="loginbox mx-auto d-block col-lg-8 mt-5 mb-5">
                <div className="loginform p-4">
                    <h2 className="text-center mb-4" style={{ marginLeft: "20px" }}>
                        Add Trainer
                    </h2>
                  <form onSubmit={Submitted}>
                      <div className='text-white text-center'>
                        <h3>Week: {formatDate(week)}</h3>
                      </div>
                      <div className='text-white text-center'   >
                        <h5>Customer Name: {customerName}</h5>
                      </div>
                    <div className="form">
                      <label className="text-white form-label " style={{ marginLeft: "20px" }}>Session Score out of 10</label>
                      <input className="w-100" type="number" placeholder="Session Score out of 10" value={sessionScore} onChange={(e) => setSessionScore(e.target.value)} required />
                      <label className="text-white form-label " style={{ marginLeft: "20px" }}>Diet Score</label>
                      <input type="text" className="w-100"  placeholder="Diet Score out of 10" value={dietScore} onChange={(e) => setDietScore(e.target.value)} required />
                   
                      <label className="text-white form-label " style={{ marginLeft: "20px" }}>Height in cm</label>
                      <input type="text" className="w-100"  placeholder="Height in cm" value={height} onChange={(e) => setHeight(e.target.value)} required />
                   
                   
                      <label className="text-white form-label " style={{ marginLeft: "20px" }}>Weight in kg </label>
                      <input type="text" className="w-100" placeholder="Weight in kg" value={weight} onChange={(e) => setWeight(e.target.value)}required />
                   
                   
                      <button type="submit" className="btn btn-danger text-light mt-3" style={{ marginLeft: "20px" }}>
                       Add
                      </button>
                    </div>
                  </form>
                 
               </div>
               </div>

          </div>
        </section>
      )}
    </>
  );
};
 