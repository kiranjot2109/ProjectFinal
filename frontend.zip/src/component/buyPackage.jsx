import { Link, useNavigate } from "react-router-dom";
import ApiServices from "./layout/ApiServices";
import { useEffect, useState } from "react";
import ReactModal from "react-modal";
import { toast } from "react-toastify";

const override= {

    margin: "0 auto",
    marginTop: "250px",
    marginBottom: '200px',
    display:'flex',
    justifyContent: 'center',
    alignItems: 'center',
    overflow:"hidden"
  };
  
  const customStyles = {
      content: {
        top: '50%',
        left: '50%',
        right: 'auto',
        bottom: 'auto',
        marginRight: '-50%',
        transform: 'translate(-50%, -50%)',
        borderRadius:'20px',
        width:'40%',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)'
      },
    };
export default function buyPackage(){
 
    const [isLoading, setIsLoading] = useState(true);
    const [data,setData]=useState([])
    let [color, setColor] = useState("#2c4964;");
    const [modalIsOpen, setIsOpen] = useState(false);
    const [selectedWork, setSelectedWork] = useState(null);
    // const [photographerId, setPhotographerId] = useState(null);
    const [bookingDate, setBookingDate] = useState('');
    const [bookingTime, setBookingTime] = useState('');
    const [dateError, setDateError] = useState('');

    const [purpose, setPurpose] = useState('');
    let nav = useNavigate()

    useEffect(()=>{

        ApiServices.GetAllPackages()
        .then((res)=>{
            console.log(res)
            setData(res.data.data)
        }).catch((err)=>{
            console.log(err);
        })
        setTimeout(() => {
          setIsLoading(false);
        }, 1500);
    },[])

      
    const handleBookClick = (_id,) => {
    
        setSelectedWork(_id); 
        const storedToken = sessionStorage.getItem("token");
        if(!storedToken){
          toast.error("user not authenticated! Login first");
          nav("/login")
       
        }      
          setIsOpen(true);

    };

    
    const closeModal = () => {
        const confirmation=
        window.confirm("Are you Really want to cancel booking?")
        if (confirmation) {
         setIsOpen(false);
        setSelectedWork(null);
        setBookingDate('');
        } else {
          setIsOpen(true);
        }
     
      };

      const book=()=>{      
            
        let data = {
          packageId:selectedWork,
          bookingDate:bookingDate,
          customerId:sessionStorage.getItem('customerId')
         
        } 
        ApiServices.BookingAdd(data)
        .then(
          (res)=>{
            if(res.data.success===true){
            toast.success(res.data.message)
            nav("/mybookings")
          }
          else{
            toast.error(res.data.message)
            setIsOpen(false)
          }}
        ).catch((error)=>{
          console.log(error);
          toast.error(error.data.message)
          
        })
      }

      const handleDateChange = (e) => {
        const selectedDate = new Date(e.target.value);
        const currentDate = new Date();
    
        if (selectedDate < currentDate) {
          setDateError('Date cannot be in the past!');
        } else {
          setDateError('');
          setBookingDate(e.target.value);
        }
      };


    return(
        <>
        {/* Breadcrumb Section Begin */}
        <section
          className="breadcrumb-section set-bg"
          data-setbg="/assets/img/breadcrumb-bg.jpg"
    style={{backgroundImage:"url(assets/img/breadcrumb-bg.jpg)"}}

        >
          <div className="container">
            <div className="row">
              <div className="col-lg-12 text-center">
                <div className="breadcrumb-text">
                  <h2>Services</h2>
                  <div className="bt-option">
                    <Link to="/">Home</Link>
                    <span>Services</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* Breadcrumb Section End */}
      
        <section className="pricing-section service-pricing spad">
          <div className="container">
            <div className="row">
              <div className="col-lg-12">
                <div className="section-title">
                  <span>Our Plan</span>
                  <h2>Choose your pricing plan</h2>
                </div>
              </div>
            </div>
          
      
            <div className="row justify-content-center">
          {data && data.length>0?
          data?.map(
                    (el,index)=>(
            <>
          <div>
          <div className="col-lg-12 col-md-8">
                <div className="ps-item">
                  <h4 className="text-warning">{el.duration }</h4>
                  <div className="pi-price">
                    <h2>{el.name}</h2>
                    <span>Rs:{el.price }</span>
                  </div>
                  {/* <ul>
                    <li>Free riding</li>
                    <li>Unlimited equipments</li>
                    <li>Personal trainer</li>
                    <li>Weight losing classes</li>
                    <li>Month to mouth</li>
                    <li>No time restriction</li>
                  </ul> */}
                  <button  className="primary-btn pricing-btn justify-center " style={{marginLeft:"100px"}}  onClick={(e)=>handleBookClick(el?._id)}  >
                    Enroll now
                  </button>
                  {/* <a href="#" className="thumb-icon">
                    <i className="fa fa-picture-o" />
                  </a> */}
                </div>
              </div>         
      </div> 
      <ReactModal
        isOpen={modalIsOpen}
     
        onRequestClose={closeModal}
        style={customStyles}
      > 
      <div>
      <div className="form-group">
                  <label htmlFor="bookingDate">Date of Booking:</label>
                  <input
                    type="date"
                    id="bookingDate"
                    className="form-control"
                    value={bookingDate}
                    onChange={handleDateChange}
                       
                  />
                </div>
                {dateError && (
        <div className="text-danger">{dateError}</div>
      )}
              </div>

                
                <div className="modal-footer gap-5 d-flex justify-content-center mt-3">
                <button type="button" className="btn btn-danger" onClick={closeModal}>Close</button>
                <button type="button" className="btn btn-primary" onClick={(e)=>book(el._id)}>Buy Package</button>
              </div>

      </ReactModal>
</>))
:
<h4>Currently No Packages Available!!</h4>
}
  
</div>
    </div>
   


         
         
         
        </section>
     
        {/* Pricing Section End */}
        {/* Get In Touch Section Begin */}
        <div className="gettouch-section">
          <div className="container">
            <div className="row">
              <div className="col-md-4">
                <div className="gt-text">
                  <i className="fa fa-map-marker" />
                  <p>
              Dasuya ,Distt: Hoshiarpur
            </p>
                </div>
              </div>
              <div className="col-md-4">
                <div className="gt-text">
                  <i className="fa fa-mobile" />
                  <ul>
                  <li>81468XXXXX</li>
                  <li>98779XXXXX</li>
                  </ul>
                </div>
              </div>
              <div className="col-md-4">
                <div className="gt-text email">
                  <i className="fa fa-envelope" />
                  <p>kaurkiranjot47@gmail</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Get In Touch Section End */}
    
        {/* Search model Begin */}
        <div className="search-model">
          <div className="h-100 d-flex align-items-center justify-content-center">
            <div className="search-close-switch">+</div>
            <form className="search-model-form">
              <input type="text" id="search-input" placeholder="Search here....." />
            </form>
          </div>
        </div>
        {/* Search model end */}
        {/* Js Plugins */}
      </>
         
    )
}