import React, { useEffect, useState } from "react"
import { toast } from "react-toastify"
import { Link, useNavigate, useParams, Navigate } from "react-router-dom"

import { ClipLoader } from "react-spinners"
import Modal from 'react-modal';
import ApiServices from "../layout/ApiServices";

const override = {

    margin: "0 auto",
    marginTop: "250px",
    marginBottom: '200px',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    overflow: "hidden"
};

const customStyles = {
    content: {
        top: '50%',
        left: '50%',
        right: 'auto',
        bottom: 'auto',
        marginRight: '-50%',
        transform: 'translate(-50%, -50%)',
        borderRadius: '20px',
        width: '30%',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)'
    },
};
export default function AssignTrainer() {

    const [isLoading, setIsLoading] = useState(true);
    const [data, setData] = useState([])
    const [alldata, setAllData] = useState([])
    let [color, setColor] = useState("#2c4964;");
    const [modalIsOpen, setIsOpen] = useState(false);
    const [selectedWork, setSelectedWork] = useState(null);
    const [customerId, setCustomerId] = useState("");
    const [packageId, setPackageId] = useState("");
    const [bookingDate, setBookingDate] = useState('');
    const [start, setStart] = useState('');
    const [dateError, setDateError] = useState('');

    const [purpose, setPurpose] = useState('');
    let nav = useNavigate()
    const param = useParams()
    console.log(param);
    const id = param.id


    useEffect(() => {
        let single = {
            _id: id
        }
        ApiServices.BookingSingle(single)

            .then((res) => {

                setCustomerId(res.data.data.customerId)
                console.log('customerId', res.data.data.customerId)
                setPackageId(res.data.data.packageId);
            }).catch((err) => {
                console.log(err);
            })

    }, [])

    useEffect(() => {
        let assignedTrainers = {
            customerId: customerId
        }
        ApiServices.TrainerAssignAll(assignedTrainers)
            .then((res) => {
                setAllData(res.data.data)
                //  console.log('al trainers',res)

            }).catch((err) => {
                console.log(err);
            })

    }, [customerId])


    useEffect(() => {
        // Get assigned trainer IDs

        ApiServices.GetAllTranier()

            .then((res) => {

                setData(res.data.data)
                //  console.log("trainers",res)
            }).catch((err) => {
                console.log(err);
            })
        setTimeout(() => {
            setIsLoading(false);
        }, 1500);
    }, [])

    const assignedTrainerIds = alldata?.map((item) => item.trainerId?._id);

    // Filter trainers that are not yet assigned
    const unassignedTrainers = data.filter(
        (trainer) => !assignedTrainerIds?.includes(trainer._id) && trainer.status === true
    );

    const handleBookClick = (_id) => {
        // e.preventDefault()
        setSelectedWork(_id);
        const storedToken = sessionStorage.getItem("token");
        if (!storedToken) {
            toast.error("user not authenticated! Login first");
            // nav("/login")

        }
        setIsOpen(true);

    };


    const closeModal = () => {
        const confirmation =
            window.confirm("Are you Really want to cancel booking?")
        if (confirmation) {
            setIsOpen(false);
            setSelectedWork(null);
            setBookingDate('');
        } else {
            setIsOpen(true);
        }

    };

    const book = () => {
        // e.preventDefault() 
        let data = {
            trainerId: selectedWork,
            packageId: packageId,
            customerId: customerId,
            start: start,


        }
        ApiServices.TrainerAssignAdd(data)
            .then(
                (res) => {
                    if (res.data.success === true) {
                        toast.success(res.data.message)
                        nav("/admin/requests")

                    }
                    else {
                        toast.error(res.data.message)
                        setIsOpen(false)
                    }
                }
            ).catch((error) => {
                console.log(error);
                toast.error(error.data.message)

            })
    }

    const handleDateChange = (e) => {
        const selectedDate = new Date(e.target.value);
        const currentDate = new Date();

        if (selectedDate < currentDate) {
            setDateError('Date cannot be in the past!');
        } else {
            setDateError('');
            setStart(e.target.value);
        }
    };
    return (
        <>
            {isLoading && (
                <ClipLoader
                    color={color}
                    loading={isLoading}
                    cssOverride={override}
                    size={100}
                    aria-label="Loading Spinner"
                    data-testid="loader"
                />
            )}
            <section
                className="breadcrumb-section set-bg"
                style={{ backgroundImage: "url(/assets/img/breadcrumb-bg.jpg)" }}
            >
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12 text-center">
                            <div className="breadcrumb-text">
                                <h2>Assign Trainer</h2>
                                <div className="bt-option">
                                    <Link to="/">Home</Link>
                                    <span>Trainers</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            {!isLoading && (
                <>
                    {/* contact section */}
                    <section class="contact_section layout_padding">
                        <div class="container">
                            <section id="departments" className="departments">
                                <div className="container" style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center' }}>
                                    <h2>
                                        <span>
                                            Assign Trainer
                                        </span>
                                    </h2>
                                    {alldata?.map(
                                        (el, index) => (
                                            <>
                                                <div  className="row">

                                                    <div class="card m-5" style={{ width: "18rem" }} key={index}>
                                                        <div class="heading_container">

                                                        </div>
                                                        <div class="card-body">
                                                            <h5 class="card-title">{el.trainerId?.name}</h5>


                                                            {/* <span class="badge badge-info text-dark" style={{backgroundColor:'#ACE2E1'}}> Status </span>{el.trainerId?.status==true?'Active':el.trainerId?.status==false?'Inactive':el.trainerId?.status}<br></br>   */}
                                                            <span class="badge badge-info text-dark" style={{ backgroundColor: '#ACE2E1' }}> Email</span> {el.trainerId?.email}<br></br>
                                                            <span class="badge badge-info text-dark" style={{ backgroundColor: '#ACE2E1' }}> Address</span> {el.trainerId?.address}<br></br>
                                                            <span class="badge badge-info text-dark" style={{ backgroundColor: '#ACE2E1' }}> Experience</span> {el.trainerId?.experience}



                                                            <p>
                                                                {el.description}
                                                            </p>
                                                        </div>
                                                    </div>

                                                </div>

                                            </>))}
                                </div>
                            </section>


                            <div class="heading_container">
                                <h2>
                                    <span>
                                        Assign Trainer
                                    </span>
                                </h2>
                            </div>
                            <section id="departments" className="departments">
                                <div className="container" style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center' }}>
                                    {unassignedTrainers.map((el, index) => (
                                        <div key={index}>
                                            <div className="card m-4" style={{ width: "18rem" }}>
                                                <div className="card-body">
                                                    <img src={el?.profile} style={{ height: "250px", width: "250px" }} />
                                                    <h5 className="card-title">{el.name}</h5>
                                                    <span className="badge badge-info text-dark" style={{ backgroundColor: '#ACE2E1' }}> Status </span> {el?.status ? 'Active' : 'Inactive'}<br />
                                                    <span className="badge badge-info text-dark" style={{ backgroundColor: '#ACE2E1' }}> Email</span> {el.email}<br />
                                                    <span className="badge badge-info text-dark" style={{ backgroundColor: '#ACE2E1' }}> Address</span> {el.address}<br />
                                                    <span className="badge badge-info text-dark" style={{ backgroundColor: '#ACE2E1' }}> Experience</span> {el.experience}
                                                    <p>{el.description}</p>
                                                    <center>
                                                        <button className="btn btn-primary text-light" onClick={() => handleBookClick(el._id)}>Assign Trainer</button>
                                                    </center>
                                                    <Modal
                                                        isOpen={modalIsOpen}
                                                        onRequestClose={closeModal}
                                                        style={customStyles}
                                                    >
                                                        <div>
                                                            <div className="form-group">
                                                                <label htmlFor="bookingDate">Start Date:</label>
                                                                <input
                                                                    type="date"
                                                                    id="bookingDate"
                                                                    className="form-control"
                                                                    value={start}
                                                                    onChange={handleDateChange}
                                                                />
                                                            </div>
                                                            {dateError && <div className="text-danger">{dateError}</div>}
                                                        </div>
                                                        <div className="modal-footer gap-5 d-flex justify-content-center mt-3">
                                                            <button type="button" className="btn btn-danger" onClick={closeModal}>Close</button>
                                                            <button type="button" className="btn btn-primary" onClick={() => book(el._id)}>Assign Trainer</button>
                                                        </div>
                                                    </Modal>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </section>

                        </div>
                    </section>
                    {/* end contact section */}
                </>
            )}
        </>
    )
}