import { Link, useNavigate } from "react-router-dom";
import ApiServices from "../layout/ApiServices";
import { useState, useEffect } from "react";
import { toast, ToastContainer } from "react-toastify";
import ClipLoader from "react-spinners/ClipLoader";
import "react-toastify/dist/ReactToastify.css";
const override= {

  margin: "0 auto",
  marginTop: "250px",
  marginBottom: '200px',
  display:'flex',
  justifyContent: 'center',
  alignItems: 'center',
  overflow:"hidden"
};
export default function ViewQueries() {
    const nav=useNavigate()  //hook must be called outside function
    const [x,setX]=useState(false)
    const [data,setData]=useState([])
    let [color, setColor] = useState("#2c4964;");
    const [isLoading, setIsLoading] = useState(true);


    useEffect(()=>{
        ApiServices.QueryAll().then((res)=>{
          console.log("Result is",res)
          // console.log(res.data.data)
          setIsLoading(false)
          setData(res.data.data)
          // setSpecialist(res.data.data)
      })
        .catch((err)=>{console.log(err)})
        setTimeout(() => {
          setIsLoading(false);
        }, 1500);
      },[x])

    const handleDelete =(_id)=>{
      var confirm = window.confirm("Are you sure to delete this?")
      if(confirm){
        ApiServices.QueryDelete({_id:_id})
        .then((res)=>{
          setIsLoading(true)
          setX(true)
            console.log(res);
            
        })
        .catch((err)=>{
          console.log(err);
          
        })
      }

    }
  return (
    <>
      <ToastContainer position="top-right" autoClose={2000} />

      <section
        className="breadcrumb-section set-bg"
        style={{ backgroundImage: "url(/assets/img/breadcrumb-bg.jpg)" }}
      >
        <div className="container">
          <div className="row">
            <div className="col-lg-12 text-center">
              <div className="breadcrumb-text">
                <h2>Manage Queries</h2>
                <div className="bt-option">
                  <Link to="/">Home</Link>
                  <span>Manage Queries</span>
                </div>
              </div>
            </div>
          </div> 
        </div>
      </section>
      <>
        {isLoading &&(
            <ClipLoader
            color={color}
            loading={isLoading}
            cssOverride={override}
            size={100}
            aria-label="Loading Spinner"
            data-testid="loader"
          />
          )}
          {!isLoading &&(
        <>
        <section className="contact_section layout_padding">
        <div className="container">
          <div className="heading_container">
            <h2 className="">
              {/* <span>Packages</span> */}
            </h2>
            {/* <Link className="nav-link col-1" to="/admin/addtrainer">
                <button type="button" class="btn btn-primary btn-lg mx-5">Add</button>
            </Link> */}
          </div>
          <div className='table-responsive'>
          <table className=" table table-hover table-striped table mt-5">
            <thead className="table-dark">
                <tr>
                    <th>Sr.No</th>
                    <th>Name</th>
                    <th>Contact</th>
                    <th>Subject</th>
                    <th>Message</th>
                    {/* <th>Status</th> */}
                    <th>Action</th>
                    {/* <th>Delete</th> */}
                </tr>
            </thead>
            <tbody >
            {data?.map(
                (el,index)=>(
                <tr >
                    <td>{index+1}</td>
                    <td>{el?.customerId?.name}</td>
                    <td>{el?.contact}</td>
                    <td>{el?.subject}</td>
                    <td>{el?.message}</td>
                    {/* <td>{el.status?"true":"false"}</td> */}
                    <td> <Link onClick={(e)=>{handleDelete(el._id)}} className="text-light btn btn-danger">
                   Delete                      
                    </Link> 
                   
                    </td>
                </tr>
                ))}
            </tbody>
        </table>
        </div>
        </div>
        </section>
       
          </>
        )} 
        </>
    </>
  );
}
