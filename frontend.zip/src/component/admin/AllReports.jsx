import { Link, useNavigate } from "react-router-dom";
import ApiServices from "../layout/ApiServices";
import { useState, useEffect } from "react";
import { toast, ToastContainer } from "react-toastify";
import ClipLoader from "react-spinners/ClipLoader";
import "react-toastify/dist/ReactToastify.css";
const override= {

    margin: "0 auto",
    marginTop: "250px",
    marginBottom: '200px',
    display:'flex',
    justifyContent: 'center',
    alignItems: 'center',
    overflow:"hidden"
  };

export default function AllReports() {
   
    const nav=useNavigate()  //hook must be called outside function
    const [x,setX]=useState(false)
    const [data,setData]=useState([])
    let [color, setColor] = useState("#2c4964;");
    const [isLoading, setIsLoading] = useState(true);


    useEffect(()=>{
      let data= {
        //  trainerId:sessionStorage.getItem("trainerId")
      }
        ApiServices.Reportall(data).then((res)=>{
          console.log("Result is",res)
          // console.log(res.data.data)
          setData(res.data.data)
          // setSpecialist(res.data.data)
      })
        .catch((err)=>{console.log(err)})
        setTimeout(() => {
          setIsLoading(false);
        }, 1500);
      },[x])


    const formatDate = (dateString) => {
        const date = new Date(dateString);
        // Example format: "MM/DD/YYYY"
        const formattedDate = `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`;
        return formattedDate;
    };

  return (
    <>
      <ToastContainer position="top-right" autoClose={2000} />

      <section
        className="breadcrumb-section set-bg"
        style={{ backgroundImage: "url(/assets/img/breadcrumb-bg.jpg)" }}
      >
        <div className="container">
          <div className="row">
            <div className="col-lg-12 text-center">
              <div className="breadcrumb-text">
                <h2>Reports</h2>
                <div className="bt-option">
                  <Link to="/">Home</Link>
                  <span>Reports</span>
                </div>
              </div>
            </div>
          </div> 
        </div>
      </section>
      <>
    {isLoading &&(
        <ClipLoader
        color={color}
        loading={isLoading}
        cssOverride={override}
        size={100}
        aria-label="Loading Spinner"
        data-testid="loader"
      />
      )}
      {!isLoading &&(
        <>
     <section class="contact_section layout_padding">
                <div class="container">
                    <div class="heading_container">
                        <h2>
                            <span>
                                All Reports
                            </span>
                        </h2>
                    </div>
                    <section id="departments" className="departments">
    <div className="container" style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center' }}>
    
      {data?.filter(el=>el.status==true).map(
                (el,index)=>(
        <>
      <div> 
      <div class="card m-3 shadow" style={{width: "18rem"}} key={index}>
  <div class="card-body">
    <h5 class="card-title">Customer Name:{el.customerId.name}</h5>
    <h5 class="card-title">Trainer Name:{el.trainerId.name}</h5>

    <h5 class="card-title">week:{formatDate(el.week)}</h5>


                          
                <span class="badge badge-info text-dark mt-2" style={{backgroundColor:'#ACE2E1'}}> Session Score </span>{el?.sessionScore}<br></br>  
                <span class="badge badge-info text-dark mt-2" style={{backgroundColor:'#ACE2E1'}}> Diet Score</span> {el?.dietScore }<br></br>
                <span class="badge badge-info text-dark mt-2" style={{backgroundColor:'#ACE2E1'}}> Height</span> {el?.height } <br></br>
                <span class="badge badge-info text-dark mt-2" style={{backgroundColor:'#ACE2E1'}}> Weight</span> {el?.weight } <br></br>
                <span class="badge badge-info text-dark mt-2" style={{backgroundColor:'#ACE2E1'}}> BMI</span> {el?.BMI } 
    <center> 
               
              
                      
   </center>
  </div>
</div>
               
      </div> 
      
</>))}
    </div>
  </section>
                </div>
            </section>
            </>
        )}
        </>
      
    </>
  );
}
