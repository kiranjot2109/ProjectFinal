import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

import { toast, ToastContainer } from "react-toastify";
import { ClipLoader } from "react-spinners";
import ApiServices from "../layout/ApiServices";
const override = {

    margin: "0 auto",
    marginTop: "250px",
    marginBottom: '200px',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    overflow: "hidden"
};
export default function UpdatePackage() {
    const param=useParams()
    console.log(param);
    const id=param.id 
    console.log("Id is :",id)
    const [duration, setDuration] = useState("")
    const [price, setPrice] = useState()
    const [features, setFeatures] = useState()
    const [name, setName] = useState()
    let [color, setColor] = useState("#2c4964;");
    const [load, setLoad] = useState(false)
    const [isLoading, setIsLoading] = useState(true);
  
    const nav = useNavigate()    
    
  
      useEffect(()=>{
        let data={
            _id:id
            
        }
        console.log("Data is:",data)
            ApiServices.SinglePackage(data)
            .then((res)=>{
                console.log("Category result is :",res);
     
                setName(res.data.data.name)
                setDuration(res.data.data.duration)
                setFeatures(res.data.data.features)
                setPrice(res.data.data.price)
  
               
            }).catch((err)=>{
                console.log(err);
            })
       },[id])
  
  
       const Submitted=(e)=>{
        e.preventDefault()
        let obj ={
          Authorization:sessionStorage.getItem("token")
        }
        console.log("obj is:",obj)
        let data={
          _id:id,
          name:name,
          duration:duration,
          price:price,
          features:features
          }
    
         
      ApiServices.UpdatePackage(data).then((res)=>{
        toast.success(res.data.message)
        nav("/admin/ManagePackage")
        
    }).catch((err)=>
       toast.error(err.data.message))
      }
  
    return (
        <>
            {/* Breadcrumb Section Begin */}
            <section
                className="breadcrumb-section set-bg"
                data-setbg="assets/img/breadcrumb-bg.jpg"
                style={{ backgroundImage: "url(/assets/img/breadcrumb-bg.jpg)" }}

            >
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12 text-center">
                            <div className="breadcrumb-text">
                                <h2>Update Package </h2>
                                <div className="bt-option">
                                    <Link to="/">Home</Link>
                                    <a href="/">Pages</a>
                                    <span>Update Package </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            {/* Breadcrumb Section End */}
            <div className="container-fluid">
                <div className="row justify-content-center">
                    <ToastContainer />

                    <ClipLoader loading={load} size={"100px"} />
                    {
                        !load ?
                            <div className="loginbox mx-auto d-block col-lg-6 mt-5 mb-5">
                                <div className="loginform p-4">
                                    <h2 className="text-center mb-4" style={{ marginLeft: "20px" }}>
                                        Add Package
                                    </h2>
                                    <form onSubmit={Submitted} >
                                        <div className="form">
                                            <label className="text-white form-label " style={{ marginLeft: "20px" }}>Name</label>
                                            <input className="w-100" type="text" placeholder="Enter Name" value={name} onChange={(e) => setName(e.target.value)} required />
                                            <label className="text-white form-label " style={{ marginLeft: "20px" }}>Duration</label><input type="text" className="w-100" placeholder="Enter Duration" value={duration} onChange={(e) => setDuration(e.target.value)} required />
                                            <label className="text-white form-label " style={{ marginLeft: "20px" }}>Features</label><input type="text" className="w-100" placeholder="Enter features" value={features} onChange={(e) => setFeatures(e.target.value)} required />
                                            <label className="text-white form-label " style={{ marginLeft: "20px" }}>Price</label><input type="text" className="w-100" value={price} onChange={(e) => setPrice(e.target.value)} required />

                                            <button type="submit" className="btn btn-danger text-light mt-3"  style={{marginLeft:"20px"}}>
                                                {load ? <ClipLoader size={20} color="#fff" /> : "Update"}
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div> : ""
                    }
                </div>
            </div>

        </>
    );
}