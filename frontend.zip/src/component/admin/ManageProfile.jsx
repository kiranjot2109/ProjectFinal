import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import ApiServices from "../layout/ApiServices";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { ClipLoader } from "react-spinners";
import { useNavigate } from "react-router-dom";

export default function RegisterTrainer() {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [experience, setExperience] = useState("");
    const [contact, setContact] = useState("");
    const [address, setAddress] = useState("");
    const [profile, setProfile] = useState("");
    const [loading, setLoading] = useState(false);
    const [message, setMessage] = useState("");
    const nav=useNavigate();
    useEffect(()=>{
      ApiServices.SingleTrainer({_id:sessionStorage.getItem("_id")})
      .then((res)=>{
        console.log("data is ",res);
        setName(res.data.data.name)
        setEmail(res.data.data.email)
        setContact(res.data.data.contact)
        setAddress(res.data.data.address)
        setExperience(res.data.data.experience)
        setProfile(res.data.data.profile)
        

      })
      .catch((err)=>{
        console.log("err is ",err);
        
      })
    },[])

    const handleSubmit = (e) => {
        e.preventDefault();

        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const passwordPattern = /[1-9]/;
        if (!emailPattern.test(email)) {
            toast.error("Invalid Email Format");
            return;
        }

      

        if (!profile) {
            toast.error("Profile Image is Required");
            return;
        }

        setLoading(true);

        const formData = new FormData();
        formData.append("name", name);
        formData.append("_id", sessionStorage.getItem("_id"));
        formData.append("email", email);
       
        formData.append("contact", contact);
        formData.append("experience", experience);
        formData.append("address", address);
        formData.append("profile", profile);
        ApiServices.UpdateTrainer(formData)
            .then((res) => {
                setLoading(false);
                setMessage(res.data.message);
                if(res.data.success){
                  toast.success(res.data.message);
                  setTimeout(()=>{
                      nav("/trainer/manageprofile")
                  },2000)

                }
                else{
                  toast.error(res.data.message)
                }
                // clear form
            })
            .catch(() => {
                setLoading(false);
                toast.error("Something went wrong!");
            });
    };

    return(
        <>
            <ToastContainer />
            <section className="breadcrumb-section set-bg"
                data-setbg="assets/img/breadcrumb-bg.jpg"
                style={{ backgroundImage: "url(/assets/img/breadcrumb-bg.jpg)" }}>
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12 text-center">
                            <div className="breadcrumb-text">
                                <h2>Manage Profile</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <div className="container-fluid">
            <div className="row">
                <div className="offset-md-9 col-md-3 mt-4">
                    <Link className="btn btn-danger"style={{ backgroundColor: "orangered", padding: "5px,10px", borderRadius: "10px", color: "white", fontSize: "15px" }}  to={"/trainer/changepass"}>Change Password</Link>

                </div>
            </div>
                <div className="row justify-content-center">
                    <div className="loginbox mx-auto d-block col-lg-4 mt-5 mb-5 ">
                             <div className="row">
                                <div className="offset-md-3  col-md-6">
                                    <img src={profile} alt=""/>
                                </div>
                              
                              </div> 
                        <div className="loginform p-4">
                            <h2 className="text-center mb-4" style={{ marginLeft: "20px" }}>
                                Manage Profile
                            </h2>


                            <form onSubmit={handleSubmit}>
                                <div className="form">
                                   <label className="text-white form-label " style={{marginLeft:"20px "}}>Name</label><input type="text" placeholder="Enter Name" value={name} onChange={(e) => setName(e.target.value)} required />
                                   <label className="text-white form-label " style={{marginLeft:"20px "}}>Email</label><input type="email" placeholder="Enter Email" value={email} onChange={(e) => setEmail(e.target.value)} required readOnly/>
                                   <label className="text-white form-label " style={{marginLeft:"20px "}}>Address</label><input type="text" placeholder="Enter Address" value={address} onChange={(e) => setAddress(e.target.value)} required />
                                   <label className="text-white form-label " style={{marginLeft:"20px "}}>Experience</label><input type="text" placeholder="Experience (e.g. 5 Years)" value={experience} onChange={(e) => setExperience(e.target.value)} required />
                                   <label className="text-white form-label " style={{marginLeft:"20px "}}>Image</label> <input type="file" className="bg-light" onChange={(e) => setProfile(e.target.files[0])}  />
                                   <label className="text-white form-label " style={{marginLeft:"20px "}}>Contact</label> <input type="number" placeholder="Enter Contact Number" value={contact} onChange={(e) => setContact(e.target.value)} required />
                                   {/* <label className="text-white form-label " style={{marginLeft:"20px"}}>Password</label>  <input type="password" placeholder="Enter Password Here" value={password} onChange={(e) => setPassword(e.target.value)} required /> */}

                                    <button type="submit" className="btn2 mt-3" disabled={loading}>
                                        {loading ? <ClipLoader size={20} color="#fff" /> : "Update"}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
