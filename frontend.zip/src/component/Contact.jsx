import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import ApiServices from "./layout/ApiServices";
import { toast } from "react-toastify";
const override= {

  margin: "0 auto",
  marginTop: "250px",
  marginBottom: '200px',
  display:'flex',
  justifyContent: 'center',
  alignItems: 'center',
  overflow:"hidden"
};
export default function Contact(){
  var[contact,setContact]=useState("")
  var[Subject,setSubject]=useState("")
  const [load, setLoad] = useState(false)
  var[Message,setMessage]=useState("")
  const nav = useNavigate()
    useEffect(()=>{
       var userType = sessionStorage.getItem("userType")
       if(userType != 3){
        toast.error("Please Login first!!")
        nav("/login")
       }
    },[])

  function handleSubmit(e){
      e.preventDefault()
      let data = {
        contact:contact,
        subject:Subject,
        message:Message,
        customerId:sessionStorage.getItem("customerId")
      }
      ApiServices.QueryAdd(data)
        .then((res) => {
          setLoad(false); // 👈 Stop loader here
                      if (res.data.success) {
                          toast.success(res.data.message);
                      setContact("")
                      setMessage("")
                      setSubject("")
                          setTimeout(() => {
                              nav("/contact");
                              toast.dismiss()
                          }, 1500); // Give time for toast to show
                      } else {
                          toast.error(res.data.message);
                      }
                  })
                  .catch((err) => {
                    setLoad(false); // 👈 Stop loader on error
                      toast.error("Internal server error!!");
                  });
  }
    return(
        <>
  {/* Breadcrumb Section Begin */}
  <section
    className="breadcrumb-section set-bg"
    data-setbg="assets/img/breadcrumb-bg.jpg"
    style={{backgroundImage:"url(assets/img/breadcrumb-bg.jpg)"}}
  >
    <div className="container">
      <div className="row">
        <div className="col-lg-12 text-center">
          <div className="breadcrumb-text">
            <h2>Contact Us</h2>
            <div className="bt-option">
              <Link to="/">Home</Link>
              <a href="#">Pages</a>
              <span>Contact us</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Breadcrumb Section End */}
  {/* Contact Section Begin */}
  <section className="contact-section spad">
    <div className="container">
      <div className="row">
        <div className="col-lg-6">
          <div className="section-title contact-title">
            <span>Contact Us</span>
            <h2>GET IN TOUCH</h2>
          </div>
          <div className="contact-widget">
            <div className="cw-text">
              <i className="fa fa-map-marker" />
              <p>
              Dasuya, Hoshiarpur
              </p>
            </div>
            <div className="cw-text">
              <i className="fa fa-mobile" />
              <ul>
                <li>9877937986</li>
              
              </ul>
            </div>
            <div className="cw-text email">
              <i className="fa fa-envelope" />
              <p>kiran@gmail.com</p>
            </div>
          </div>
        </div>
        <div className="col-lg-6">
          <div className="leave-comment">
            <form onSubmit={handleSubmit}>
              {/* <input type="text" placeholder="Name" /> */}
              <input type="text" placeholder="Contact Details" value={contact} onChange={(e)=>{setContact(e.target.value)}}/>
              <input type="text" placeholder="Subject" value={Subject} onChange={(e)=>{setSubject(e.target.value)}} />
              <textarea placeholder="Message" defaultValue={""} value={Message} onChange={(e)=>{setMessage(e.target.value)}}/>
              <button type="submit">Submit</button>
            </form>
          </div>
        </div>
      </div>
      <div className="map">
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12087.069761554938!2d-74.2175599360452!3d40.767139456514954!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c254b5958982c3%3A0xb6ab3931055a2612!2sEast%20Orange%2C%20NJ%2C%20USA!5e0!3m2!1sen!2sbd!4v1581710470843!5m2!1sen!2sbd"
          height={550}
          style={{ border: 0 }}
          allowFullScreen=""
        />
      </div>
    </div>
  </section>
  {/* Contact Section End */}
  {/* Get In Touch Section Begin */}
  <div className="gettouch-section">
    <div className="container">
      <div className="row">
        <div className="col-md-4">
          <div className="gt-text">
            <i className="fa fa-map-marker" />
            <p>
                  Dasuya ,Distt: Hoshiarpur
                  </p>
          </div>
        </div>
        <div className="col-md-4">
          <div className="gt-text">
            <i className="fa fa-mobile" />
            <ul>
          
            <li>9877937986</li>
            </ul>
          </div>
        </div>
        <div className="col-md-4">
          <div className="gt-text email">
            <i className="fa fa-envelope" />
            <p>kiran@gmail.com</p>
          </div>
        </div>
      </div>
    </div>
  </div>
  {/* Get In Touch Section End */}
  {/* Footer Section Begin */}

  {/* Footer Section End */}
  {/* Search model Begin */}
  <div className="search-model">
    <div className="h-100 d-flex align-items-center justify-content-center">
      <div className="search-close-switch">+</div>
      <form className="search-model-form">
        <input type="text" id="search-input" placeholder="Search here....." />
      </form>
    </div>
  </div>
  {/* Search model end */}
  {/* Js Plugins */}
</>

    )
}