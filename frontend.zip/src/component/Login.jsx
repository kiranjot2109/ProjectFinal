import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast ,ToastContainer} from "react-toastify";
import ApiServices from "./layout/ApiServices";
export default function Form() {
    const [Email, setEmail] = useState("")
    const [Password, setPassword] = useState("")
    const nav = useNavigate();
    useEffect(()=>{
        
    },[])
    const handleSubmit = (e) => {
        e.preventDefault();
        let data = {
            email: Email,
            password: Password
        }
        ApiServices.Login(data)
            .then((res) => {
            if(res.data.success){
                toast.success(res.data.message);
                sessionStorage.setItem("token", res.data.token)
                sessionStorage.setItem("_id", res.data.data?._id)
                sessionStorage.setItem("userType", res.data.data?.userType)
                sessionStorage.setItem("email", res.data.data?.email)
                sessionStorage.setItem("trainerId", res.data.data?.trainerId)
                sessionStorage.setItem("customerId", res.data.data?.customerId)
                if(res.data.data.userType =="1"){
                    setEmail("")
                    setPassword("")
                    setTimeout(() => {
                      
                        nav('/admin')
                    }, 1000); 
                }
                if(res.data.data.userType =="2"){
                    setEmail("")
                    setPassword("")
                        setTimeout(()=>{

                            nav('/trainer')
                        },1000)
                }
                if(res.data.data.userType =="3"){
                    setEmail("")
                    setPassword("")
                        setTimeout(()=>{
                            nav('/')
                        },1000)
                }

            }
            else{
                toast.error(res.data.message)
            }

                
            })
            .catch((err) => {
                // console.log(err);
                toast.error(err)
            })
        
        
}

    return (
        <>
            <ToastContainer/>
            
            <section className="breadcrumb-section set-bg" style={{ backgroundImage: "url(/assets/img/hero/hero-2.jpg)", height: "750px" }}>
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-lg-6 offset-lg-6 poistion-absolute top-0 end-0 m-3"></div>
                        <div className="loginbox mx-auto d-block col-lg-4">
                            <div className="loginform">
                                <form onSubmit={handleSubmit}>
                                    <br />
                                    <div className="form">
                                        <h2 style={{ color: "white" }}>Login form</h2>
                                        <input type="text" placeholder="gmail" onChange={(e) => setEmail(e.target.value)} required />
                                        <input type="password" placeholder="password" onChange={(e) => setPassword(e.target.value)} required /><br />
                                        <button className="btn2 ml-3">LOGIN</button><br />
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    );
}
