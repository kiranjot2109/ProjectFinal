import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

export default function Header(){
  const authenticate = sessionStorage.getItem('token')
  console.log(authenticate)
  const nav = useNavigate()
  const logout=()=>{
    sessionStorage.clear()
    toast.success("Logout successfully")
    setTimeout(()=>{
    nav("/login")

    })
  }

  return(
    <>
  {/* Header Section Begin */}
  <header className="header-section">
    <div className="container-fluid">
      <div className="row">
        <div className="col-lg-3">
        <h3 style={{color:"white",fontWeight:"bold",fontSize:"45px"}}> STRENGTH</h3>
          <div className="logo">
            <a href="/">
              <img src="/assets/img/logo.png" alt="" />
            </a>
          </div>
        </div>
        <div className="col-lg-7">
          <nav className="nav-menu">
            <ul>
              <li className="active">
                <Link to="/customer/">Home</Link>
              </li>
              <li>
                <Link to="/customer/dailyentry">Daily Entry</Link>
              </li>
              <li>
                <Link to="/customer/manageprofile">Manage Profile</Link>
              </li>
              <li>
                <Link to="/customer/sendrequest">Send Request</Link>
              </li>
              <li>
                <Link to="/customer/queries"> Query</Link>
              </li>
              <li>
                <Link to="/customer/dietplan">Diet Plans</Link>
              </li>
              {/* <li>
                <Link to="/workout">Workout</Link>
              </li> */}<li>
              <Link to="/customer/workout">Workout</Link>
                <ul className="dropdown">
                  <li>
                  <Link to="/customer/bmi">BMI Calculator</Link>
                  </li></ul></li>
            
              {/* <li>
                <Link to="/about-us">About Us</Link>
              </li>
              <li>
                <Link to="/classes">Classes</Link>
              </li>
              <li>
                <Link to="/services">Services</Link>
              </li>
              <li>
                <Link to="/team">Our Team</Link>
              </li>
              <li>
              <Link to="#">Pages</Link>
                <ul className="dropdown">
                  <li>
                  <Link to="/about-us">About Us</Link>
                  </li>
                  <li>
                  <Link to="/ClassTimetable">Classes timetable</Link>
                  </li>
                  <li>
                    <Link to="/BmiCalculator">Bmi calculate</Link>
                  </li>
                  <li>
                  <Link to="/team">Our Team</Link>
                  </li>
                  <li>
                    <Link to="/Gallery">Gallery</Link>
                  </li>
                  <li>
                    <Link to="/Blog">Our blog</Link>
                  </li>
                  <li>
                    <Link to="/404">404</Link>
                  </li>
                </ul>
              </li> */}
              {/* <li>
                <Link to="/contact">Contact</Link>
                </li> */}
                <Link className="btn btn-danger"style={{ backgroundColor: "orangered", padding: "5px,10px", borderRadius: "10px", color: "white", fontSize: "15px" }}  onClick={logout}>Logout</Link>
            </ul>
          </nav>
        </div>
        <div className="col-lg-2">
          <div className="top-option">
            <div className="to-search search-switch">
              <i className="fa fa-search" />
            </div>
            <div className="to-social">
              < Link to="#">
                <i className="fa fa-facebook" />
              </Link>
              < Link to="#">
                <i className="fa fa-twitter" />
              </Link>
              < Link to="#">
                <i className="fa fa-youtube-play" />
              </Link>
              < Link to="#">
                <i className="fa fa-instagram" />
              </Link>
            </div>
          {/* buttons
          <Link to="/login" className="primary-btn  btn-normal">
              LOGIN
            </Link> */}
         
          </div>
          
        </div>
      </div>
  
    </div>
  </header>
  {/* Header End */}
</>

  )
}