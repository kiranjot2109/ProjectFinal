import axios from "axios";
export const BASE_URL = "http://localhost:5000/";

class ApiServices {
    getToken() {
        let obj = {
            authorization: sessionStorage.getItem('token')
        }
        return obj
    }
    Login(data) {
        return axios.post(BASE_URL + "admin/login", data)
    }
    DashboardApi() {
        return axios.post(BASE_URL + "admin/dashboard", null, {
            headers: this.getToken()
        });
    }
    AddTrainer(data) {
        return axios.post(BASE_URL + "admin/trainer/add", data, {
            headers: this.getToken()
        });
    }
    SingleTrainer(data) {
        return axios.post(BASE_URL + "admin/trainer/single", data, {
            headers: this.getToken()
        });
    }
    UpdateTrainer(data) {
        return axios.post(BASE_URL + "admin/trainer/update", data, {
            headers: this.getToken()
        });
    }
    ChangeStatusTrainer(data) {
        return axios.post(BASE_URL + "admin/trainer/status", data, {
            headers: this.getToken()
        });
    }
    SingleCustomer(data) {
        return axios.post(BASE_URL + "admin/customer/single", data, {
            headers: this.getToken()
        });
    }
    AllCustomer() {
        return axios.post(BASE_URL + "admin/customer/all", null, {
            headers: this.getToken()
        });
    }
    ChangeStatusCustomer(data) {
        return axios.post(BASE_URL + "admin/customer/status", data, {
            headers: this.getToken()
        });
    }
    ChangePasswordTrainer(data) {
        return axios.post(BASE_URL + "admin/changePassword", data, {
            headers: this.getToken()
        });
    }
    RegisterCustomer(data) {
        return axios.post(BASE_URL + "customer/register", data)
    }
    RegisterTrainer(data) {
        return axios.post(BASE_URL + "admin/trainer/add", data, {
            headers: this.getToken()
        })
    }
    GetAllTranier() {
        return axios.post(BASE_URL + "admin/trainer/all", null, {
            headers: this.getToken()
        });
    }
    GetAllPackages() {
        return axios.post(BASE_URL + "customer/package/all", null, {
            headers: this.getToken()
        });
    }
    ChangePassword(data) {
        return axios.post(BASE_URL + "admin/trainer/changePassword", data, {
            headers: this.getToken()
        })
    }
    GetAllCustomer() {
        return axios.post(BASE_URL + "admin/customer/all", null, {
            headers: this.getToken()
        });
    }
    changeStatusTrainer(data) {
        return axios.post(BASE_URL + "admin/trainer/status", data, {
            headers: this.getToken()
        })
    }
    changeStatusCustomer(data) {
        return axios.post(BASE_URL + "admin/customer/status", data, {
            headers: this.getToken()
        })
    }
    addDietPlan(data) {
        return axios.post(BASE_URL + "trainer/diet/add", data, {
            headers: this.getToken()
        })
    }
    SessionAdd(data) {
        return axios.post(BASE_URL + "trainer/session/add", data, {
            headers: this.getToken()
        })
    }
    SessionAll(data) {
        return axios.post(BASE_URL + "trainer/session/all", data, {
            headers: this.getToken()
        })
    }
    SessionUpdate(data) {
        return axios.post(BASE_URL + "trainer/session/update", data, {
            headers: this.getToken()
        })
    }
    SessionSingle(data) {
        return axios.post(BASE_URL + "trainer/session/single", data, {
            headers: this.getToken()
        })
    }
    SessionStatus(data) {
        return axios.post(BASE_URL + "trainer/session/status", data, {
            headers: this.getToken()
        })
    }
    allDietPlan() {
        return axios.post(BASE_URL + "trainer/diet/all", null, {
            headers: this.getToken()
        })
    }
    updateDietPlan(data) {
        return axios.post(BASE_URL + "trainer/diet/update", data, {
            headers: this.getToken()
        })
    }
    deleteDietPlan(data) {
        return axios.post(BASE_URL + "trainer/diet/delete", data, {
            headers: this.getToken()
        })
    }
    changeStatusDietPlan(data) {
        return axios.post(BASE_URL + "trainer/diet/changestatus", data, {
            headers: this.getToken()
        })
    }
    singleDietPlan(data) {
        return axios.post(BASE_URL + "trainer/diet/getsingle", data, {
            headers: this.getToken()
        })
    }
    AddPackage(data) {
        return axios.post(BASE_URL + "admin/package/add", data, {
            headers: this.getToken()
        })
    }
    UpdatePackage(data) {
        return axios.post(BASE_URL + "admin/package/update", data, {
            headers: this.getToken()
        })
    }
    ChangeStatusPackage(data) {
        return axios.post(BASE_URL + "admin/package/status", data, {
            headers: this.getToken()
        })
    }
    SinglePackage(data) {
        return axios.post(BASE_URL + "admin/package/single", data, {
            headers: this.getToken()
        })
    }
    TrainerAssignAdd(data) {
        return axios.post(BASE_URL + "admin/trainer/assign", data, {
            headers: this.getToken()
        })
    }
    TrainerAssignUpdate(data) {
        return axios.post(BASE_URL + "/trainer/assign/update", data, {
            headers: this.getToken()
        })
    }
    TrainerAssignAll(data) {
        return axios.post(BASE_URL + "admin/trainer/assign/all", data, {
            headers: this.getToken()
        })
    }
    TrainerAssignSingle(data) {
        return axios.post(BASE_URL + "trainer/assign/single", data, {
            headers: this.getToken()
        })
    }
    BookingAll(data) {
        return axios.post(BASE_URL + "admin/booking/all", data, {
            headers: this.getToken()
        })
    }

    BookingStatus(data) {
        return axios.post(BASE_URL + "admin/booking/status", data, {
            headers: this.getToken()
        })
    }
    BookingSingle(data) {
        return axios.post(BASE_URL + "admin/booking/single", data, {
            headers: this.getToken()
        })
    }
    BookingAdd(data) {
        return axios.post(BASE_URL + "customer/booking/add", data, {
            headers: this.getToken()
        })
    }
    BookingPay(data) {
        return axios.post(BASE_URL + "customer/booking/pay", data, {
            headers: this.getToken()
        })
    }


    ReportSingle(data) {
        return axios.post(BASE_URL + "/report/single", data, {
            headers: this.getToken()
        })
    }
    ReportAdd(data) {
        return axios.post(BASE_URL + "trainer/report/add", data, {
            headers: this.getToken()
        })
    }
    Reportstatus(data) {
        return axios.post(BASE_URL + "trainer/report/status", data, {
            headers: this.getToken()
        })
    }
    ReportUpdate(data) {
        return axios.post(BASE_URL + "trainer/report/update", data, {
            headers: this.getToken()
        })
    }

    Reportall(data) {
        return axios.post(BASE_URL + "admin/report/all", data, {
            headers: this.getToken()
        })
    }
    Dashboard(data) {
        return axios.post(BASE_URL + "/dashboard", data, {
            headers: this.getToken()
        })
    }
    QueryChangeStatus(data) {
        return axios.post(BASE_URL + "/query/changestatus", data, {
            headers: this.getToken()
        })
    }
    QueryGetsingle(data) {
        return axios.post(BASE_URL + "/query/getsingle", data, {
            headers: this.getToken()
        })
    }
    QueryAll(data) {
        return axios.post(BASE_URL + "admin/query/all", data, {
            headers: this.getToken()
        })
    }
    QueryDelete(data) {
        return axios.post(BASE_URL + "admin/query/delete", data, {
            headers: this.getToken()
        })
    }
    QueryAdd(data) {
        return axios.post(BASE_URL + "customer/query/add", data, {
            headers: this.getToken()
        })
    }


}


export default new ApiServices;