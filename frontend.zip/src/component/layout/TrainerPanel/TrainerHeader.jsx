import { useEffect } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";

export default function TrainerHeader() {
  const navigate = useNavigate();
  const nav=useNavigate()
  useEffect(()=>{
         var userType = sessionStorage.getItem("userType")
            if(userType != 2){
             toast.error("Please Login first!!")
             nav("/login")
            }
  },[])
  const logout=()=>{
      sessionStorage.clear()
      toast.success("Logout successfully")
      setTimeout(()=>{
      nav("/login")

      },3000)
  }

  return (
    <>
      {/* Header Section Begin */}
      <header className="header-section">
        <ToastContainer/>
        <div className="container-fluid">
          <div className="row">
            <div className="col-lg-1">
            <h3 style={{color:"white",fontWeight:"bold",fontSize:"45px"}}> STRENGTH</h3>
              <div className="logo">
                <Link to="/">
                  <img src="/assets/img/logo.png" alt="" />
                </Link>
              </div>
            </div>
            <div className="col-lg-9">
              <nav className="nav-menu">
                <ul className="flex gap-6 items-center">
                  <li className="active">
                    <Link to="/trainer">Home</Link>
                  </li>
                  <li>
                    <Link to="/trainer/viewmembers">Members</Link>
                  </li>
                  <li>
                    <Link to="/trainer/managesession">Session</Link>
                  </li>
                  <li>
                    <Link to="/trainer/allReports">All Reports</Link>
                  </li>
                  <li>
                  <Link to="/trainer/manageprofile">
                         Profile
                    
                    </Link>
                  </li>
                  <li>
                  <Link to="/trainer/changepass">
                         Change Password
                    </Link>
                  </li>
               

                 
                 
                </ul>
              </nav>
            </div>
            <div className="col-lg-2">
              <div className="top-option">
                <div className="to-search search-switch">
                <li>
                    <Link to="/trainer/manageprofile">
                         <i className="fa fa-user" />
                    
                    </Link>
                  </li>
                </div>
                <div className="to-social">
                  {/* <Link to="https://www.facebook.com/share/18hVPSm9uP/">
                    <i className="fa fa-facebook" />
                  </Link>
                  <a href="#">
                    <i className="fa fa-twitter" />
                  </a>
                  <Link to="https://youtube.com/@paraskumar2836?si=8tZGoNH81FXgivze">
                    <i className="fa fa-youtube-play" />
                  </Link>
                  <Link to="https://www.instagram.com/paras_kumar990?igsh=YjdhYXVoc2pwMjgz">
                    <i className="fa fa-instagram" />
                  </Link> */}
                  <Link className="btn btn-danger"style={{ backgroundColor: "orangered", padding: "5px,10px", borderRadius: "10px", color: "white", fontSize: "15px" }}  onClick={logout}>Logout</Link>
                </div>
              </div>
            </div>
          </div>
          <div className="canvas-open">
            <i className="fa fa-bars" />
          </div>
        </div>
      </header>
      {/* Header End */}
    </>
  );
}
