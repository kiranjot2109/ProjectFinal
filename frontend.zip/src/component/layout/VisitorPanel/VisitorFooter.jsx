import { Link } from "react-router-dom";

export default function VisitorFooter (){
    return(
        <>
        {/* Footer Section Begin */}
        <section className="footer-section">
          <div className="container">
            <div className="row">
              <div className="col-lg-4">
                <div className="fs-about">
                  <div className="fa-logo">
                    <a href="#">
                      <img src="img/logo.png" alt="" />
                    </a>
                  </div>
                  <p>
                  Strenght Gym is a globally renowned fitness brand that has made its mark in India. With a strong legacy dating back to 1965, Strength Gym has become synonymous with fitness excellence and innovation.
                  </p>
                  <div className="fa-social">
                  <Link to="https://www.facebook.com/share/18hVPSm9uP/">
                      <i className="fa fa-facebook" />
                    </Link>
                    <a href="#">
                      <i className="fa fa-twitter" />
                    </a>
                    <Link to="https://youtube.com/@paraskumar2836?si=8tZGoNH81FXgivze">
                      <i className="fa fa-youtube-play" />
                    </Link>
                    <Link to="https://www.instagram.com/paras_kumar990?igsh=YjdhYXVoc2pwMjgz">
                      <i className="fa fa-instagram" />
                    </Link>
                    <a href="#">
                      <i className="fa  fa-envelope-o" />
                    </a>
                  </div>
                </div>
              </div>
              <div className="col-lg-2 col-md-3 col-sm-6">
                <div className="fs-widget">
                  <h4>Useful links</h4>
                  <ul>
                    <li>
                      <Link to="/about-us">About</Link>
                    </li>
                    <li>
                    <Link to="/Blog">blog</Link>
                    </li>
                    <li>
                    <Link to="/classes">Classes</Link>
                    </li>
                    <li>
                    <Link to="/contact">Contact</Link>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="col-lg-2 col-md-3 col-sm-6">
                <div className="fs-widget">
                  <h4>Support</h4>
                  <ul>
                    <li>
                      <a href="#">Login</a>
                    </li>
                    <li>
                      <a href="#">My account</a>
                    </li>
                    <li>
                      <a href="#">Subscribe</a>
                    </li>
                    <li>
                      <a href="#">Contact</a>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="col-lg-4 col-md-6">
                <div className="fs-widget">
                  <h4>Tips &amp; Guides</h4>
                  <div className="fw-recent">
                    <h6>
                      <a href="#">
                        Physical fitness may help prevent depression, anxiety
                      </a>
                    </h6>
                    <ul>
                      <li>3 min read</li>
                      <li>20 Comment</li>
                    </ul>
                  </div>
                  <div className="fw-recent">
                    <h6>
                      <a href="#">
                        Fitness: The best exercise to lose belly fat and tone up...
                      </a>
                    </h6>
                    <ul>
                      <li>3 min read</li>
                      <li>20 Comment</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col-lg-12 text-center">
                <div className="copyright-text">
                  <p>
                   
                    StrengthGym © All rights reserved | 
                   
                    
                   
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* Footer Section End */}
      </>
    )
}