
        // process.stdout.write("hi ");
        // process.stdout.write("hello \n");
        // process.stdout.write((2 + 2 + "\n").toString());
        // process.stdout.write((3 * 3) + " ");
        // process.stdout.write(3 + " ");
        // process.stdout.write("BYE\n");

        // for (let i = 4; i >= 0; i--) {
        //     for (let j = 4; j >= 0; j--) {
        //         if (i == j) {
        //             process.stdout.write("* ")
        //         }
        //         else {
        //             process.stdout.write("  ")
        //         }
        //     }
        //     process.stdout.write("\n")
        // }

        secure = true;
        cdn_submission = true;
        console.log(secure)
        console.log(cdn_submission)
